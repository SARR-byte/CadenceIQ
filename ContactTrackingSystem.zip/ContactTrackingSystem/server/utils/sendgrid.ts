import sgMail from '@sendgrid/mail';

// Initialize SendGrid with API key
if (!process.env.SENDGRID_API_KEY) {
  console.warn('SENDGRID_API_KEY is not set. Email functionality will not work.');
} else {
  sgMail.setApiKey(process.env.SENDGRID_API_KEY);
}

interface SendEmailOptions {
  to: string;
  subject: string;
  text?: string;
  html?: string;
}

/**
 * Sends an email using SendGrid
 */
export async function sendEmail({ to, subject, text, html }: SendEmailOptions): Promise<boolean> {
  if (!process.env.SENDGRID_API_KEY) {
    console.error('Cannot send email: SENDGRID_API_KEY is not set');
    return false;
  }
  
  try {
    const msg = {
      to,
      from: 'access@cadenceiq.co', // Replace with your verified sender
      subject,
      text: text || '',
      html: html || '',
    };
    
    await sgMail.send(msg);
    console.log(`Email sent successfully to ${to}`);
    return true;
  } catch (error) {
    console.error('Error sending email:', error);
    return false;
  }
}

/**
 * Sends an access link email to a customer
 */
export async function sendAccessEmail(email: string, accessUrl: string): Promise<boolean> {
  const subject = 'Your CadenceIQ Access Link';
  
  const text = `
    Thank you for purchasing CadenceIQ!
    
    Here's your exclusive access link to the dashboard:
    ${accessUrl}
    
    We recommend bookmarking this link for easy access in the future.
    
    If you have any questions, please contact our support team at support@cadenceiq.co.
    
    Best regards,
    The CadenceIQ Team
  `;
  
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <div style="background-color: #333333; padding: 20px; text-align: center;">
        <h1 style="color: white; margin: 0;">CadenceIQ</h1>
      </div>
      <div style="padding: 20px; border: 1px solid #eaeaea; border-top: none;">
        <p style="font-size: 16px; line-height: 1.5;">Thank you for purchasing CadenceIQ!</p>
        
        <p style="font-size: 16px; line-height: 1.5;">Here's your exclusive access link to the dashboard:</p>
        
        <p style="text-align: center; margin: 30px 0;">
          <a href="${accessUrl}" style="background-color: #333333; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px; font-weight: bold;">
            Access Your Dashboard
          </a>
        </p>
        
        <p style="font-size: 16px; line-height: 1.5;">We recommend bookmarking this link for easy access in the future.</p>
        
        <p style="font-size: 14px; color: #666; margin-top: 40px; border-top: 1px solid #eaeaea; padding-top: 20px;">
          If you have any questions, please contact our support team at 
          <a href="mailto:support@cadenceiq.co" style="color: #333333;">support@cadenceiq.co</a>.
        </p>
      </div>
    </div>
  `;
  
  return sendEmail({ to: email, subject, text, html });
}