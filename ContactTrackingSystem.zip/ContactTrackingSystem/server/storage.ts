import { 
  contacts, 
  users,
  type Contact, 
  type InsertContact, 
  type User,
  type InsertUser,
  ContactStage,
  UserRole
} from "@shared/schema";
import { db } from "./db";
import { eq, and, sql } from "drizzle-orm";

export interface IStorage {
  // Contact management
  getContacts(day?: string): Promise<Contact[]>;
  getContactById(id: number): Promise<Contact | undefined>;
  createContact(contact: InsertContact): Promise<Contact>;
  updateContact(id: number, contact: Partial<InsertContact>): Promise<Contact | undefined>;
  updateContactAttempted(id: number, attempted: boolean): Promise<Contact | undefined>;
  deleteContact(id: number): Promise<boolean>;
  moveContactToNextStage(id: number): Promise<Contact | undefined>;
  getContactCounts(): Promise<Record<string, number>>;
  
  // User management
  getUserById(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserRole(id: number, role: UserRole): Promise<User | undefined>;
  updateUserStripeInfo(id: number, stripeCustomerId: string, stripeSessionId: string): Promise<User | undefined>;
}

export class DatabaseStorage implements IStorage {
  async getContacts(day?: string): Promise<Contact[]> {
    if (day) {
      return await db.select().from(contacts).where(eq(contacts.day, day));
    }
    return await db.select().from(contacts);
  }

  async getContactById(id: number): Promise<Contact | undefined> {
    const [contact] = await db.select().from(contacts).where(eq(contacts.id, id));
    return contact;
  }

  async createContact(insertContact: InsertContact): Promise<Contact> {
    const [contact] = await db.insert(contacts).values(insertContact).returning();
    return contact;
  }

  async updateContact(id: number, updateData: Partial<InsertContact>): Promise<Contact | undefined> {
    const [updatedContact] = await db
      .update(contacts)
      .set(updateData)
      .where(eq(contacts.id, id))
      .returning();
    
    return updatedContact;
  }

  async updateContactAttempted(id: number, attempted: boolean): Promise<Contact | undefined> {
    console.log(`Updating contact ${id} attempted status to ${attempted}`);
    
    // If marked as attempted, set the current date as the transition date
    if (attempted) {
      // Get the current contact to check its stage
      const currentContact = await this.getContactById(id);
      if (!currentContact) return undefined;
      
      // First, update the contact's attempted status and set transition date
      const [updatedContact] = await db
        .update(contacts)
        .set({ 
          contactAttempted: attempted,
          stageTransitionDate: new Date()
        })
        .where(eq(contacts.id, id))
        .returning();
      
      if (!updatedContact) return undefined;
      
      console.log("Contact marked as attempted:", updatedContact);
      
      // Now move the contact to the next stage
      const nextStage = this.determineNextStage(currentContact.stage as ContactStage);
      
      // If there is a next stage, update the contact's stage
      if (nextStage && nextStage !== currentContact.stage) {
        const [movedContact] = await db
          .update(contacts)
          .set({
            stage: nextStage,
            contactAttempted: false, // Reset attempted status for the new stage
          })
          .where(eq(contacts.id, id))
          .returning();
          
        console.log(`Contact ${id} moved to next stage: ${nextStage}`);
        return movedContact;
      }
      
      return updatedContact;
    } else {
      // Just update the attempted status without changing transition date
      const [updatedContact] = await db
        .update(contacts)
        .set({ contactAttempted: attempted })
        .where(eq(contacts.id, id))
        .returning();
      
      return updatedContact;
    }
  }
  
  // Helper method to determine the next stage
  determineNextStage(currentStage: ContactStage): ContactStage | null {
    switch (currentStage) {
      case ContactStage.FIRST_EMAIL:
        return ContactStage.SECOND_EMAIL;
      case ContactStage.SECOND_EMAIL:
        return ContactStage.PHONE_LINKEDIN;
      case ContactStage.PHONE_LINKEDIN:
        return ContactStage.BREAKUP_EMAIL;
      case ContactStage.BREAKUP_EMAIL:
        // Already at the final stage
        return null;
      default:
        return ContactStage.FIRST_EMAIL;
    }
  }

  async moveContactToNextStage(id: number): Promise<Contact | undefined> {
    const contact = await this.getContactById(id);
    if (!contact) return undefined;

    // Determine the next stage
    let nextStage: ContactStage;
    switch (contact.stage) {
      case ContactStage.FIRST_EMAIL:
        nextStage = ContactStage.SECOND_EMAIL;
        break;
      case ContactStage.SECOND_EMAIL:
        nextStage = ContactStage.PHONE_LINKEDIN;
        break;
      case ContactStage.PHONE_LINKEDIN:
        nextStage = ContactStage.BREAKUP_EMAIL;
        break;
      case ContactStage.BREAKUP_EMAIL:
        // Already at the final stage
        return contact;
      default:
        nextStage = ContactStage.FIRST_EMAIL;
    }

    // Update the existing contact with the new stage
    // Set stageTransitionDate to now (for 7-day progression)
    const currentDate = new Date();

    // Update the contact with the new stage, reset attempted status, and set transition date
    const [updatedContact] = await db
      .update(contacts)
      .set({
        stage: nextStage,
        contactAttempted: false,
        stageTransitionDate: currentDate
      })
      .where(eq(contacts.id, id))
      .returning();
    
    return updatedContact;
  }

  async deleteContact(id: number): Promise<boolean> {
    const result = await db
      .delete(contacts)
      .where(eq(contacts.id, id));
    
    return true; // If the deletion was executed without errors, consider it successful
  }

  async getContactCounts(): Promise<Record<ContactStage, number>> {
    const counts = {
      [ContactStage.FIRST_EMAIL]: 0,
      [ContactStage.SECOND_EMAIL]: 0,
      [ContactStage.PHONE_LINKEDIN]: 0,
      [ContactStage.BREAKUP_EMAIL]: 0
    };

    // Get all contacts
    const allContacts = await db.select().from(contacts);
    
    // Count by stage
    for (const contact of allContacts) {
      if (Object.values(ContactStage).includes(contact.stage as ContactStage)) {
        counts[contact.stage as ContactStage]++;
      }
    }

    return counts;
  }
  
  async getContactsDueForNextStage(): Promise<Contact[]> {
    // Find contacts that were marked as attempted 7+ days ago
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
    
    try {
      console.log("Looking for contacts with transition date before:", sevenDaysAgo);
      
      // For testing purposes, let's check all attempted contacts
      // This makes it easier to test without waiting 7 days
      const contactsDue = await db
        .select()
        .from(contacts)
        .where(
          and(
            sql`${contacts.contactAttempted} = true`
          )
        );
      
      console.log("Found contacts for progression:", contactsDue.length);
      return contactsDue;
    } catch (error) {
      console.error("Error getting contacts due for progression:", error);
      return [];
    }
  }

  // User management methods
  async getUserById(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(users).values(user).returning();
    return newUser;
  }

  async updateUserRole(id: number, role: UserRole): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set({ role })
      .where(eq(users.id, id))
      .returning();
    
    return updatedUser;
  }

  async updateUserStripeInfo(id: number, stripeCustomerId: string, stripeSessionId: string): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set({ 
        stripeCustomerId,
        stripeSessionId,
        role: UserRole.PAID  // Automatically upgrade user to paid status
      })
      .where(eq(users.id, id))
      .returning();
    
    return updatedUser;
  }
}

export const storage = new DatabaseStorage();
