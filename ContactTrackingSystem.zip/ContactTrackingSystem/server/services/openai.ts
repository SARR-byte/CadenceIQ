import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function generateContactInsights(
  entityName: string,
  primaryContact: string,
  companyLinkedIn?: string,
  contactLinkedIn?: string,
  contactFacebook?: string
): Promise<string> {
  try {
    console.log("Generating insights for:", { entityName, primaryContact, companyLinkedIn, contactLinkedIn, contactFacebook });
    
    // Verify OpenAI API key is available
    if (!process.env.OPENAI_API_KEY) {
      console.error("Missing OpenAI API key");
      return "Error: OpenAI API key is missing. Please add it to your environment variables.";
    }

    const prompt = `
    Generate insightful notes for an upcoming business meeting with the following contact:
    - Company/Entity: ${entityName}
    - Contact Name: ${primaryContact}
    ${companyLinkedIn ? `- Company LinkedIn: ${companyLinkedIn}` : ''}
    ${contactLinkedIn ? `- Contact LinkedIn: ${contactLinkedIn}` : ''}
    ${contactFacebook ? `- Contact Facebook: ${contactFacebook}` : ''}

    Please provide a concise but detailed summary including:
    1. Potential company founding date/stage estimation
    2. Possible educational background of the contact
    3. Likely professional interests based on their role
    4. Relevant industry insights
    5. Potential conversation starters

    Format as a short paragraph of no more than 200 words, focusing on the most relevant details.
    `;

    console.log("Sending request to OpenAI API");
    
    // If there are no social media links, add fictional insights as example
    if (!companyLinkedIn && !contactLinkedIn && !contactFacebook) {
      console.log("No social media links provided, generating sample insights based on name only");
    }

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a helpful business intelligence assistant that creates meeting prep notes."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      max_tokens: 400,
      temperature: 0.7,
    });

    console.log("Received response from OpenAI");
    
    return response.choices[0].message.content || 
      "Unable to generate insights. Please review the provided information.";
  } catch (error) {
    console.error("Error generating contact insights:", error);
    if (error instanceof Error) {
      console.error("Error details:", error.message);
      if ('code' in error) {
        console.error("Error code:", (error as any).code);
      }
    }
    return `Error generating insights: ${error instanceof Error ? error.message : 'Unknown error'}. Please try again later.`;
  }
}