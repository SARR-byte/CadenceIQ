import express, { type Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  contactSchema, 
  contactAttemptedSchema, 
  ContactStage,
  ContactDay
} from "@shared/schema";
import { z } from "zod";
import { generateContactInsights } from "./services/openai";
import { seedInitialData } from "./seed";
import multer from "multer";
import { parse } from "csv-parse";
import fs from "fs";
import path from "path";
import Stripe from "stripe";

// Initialize Stripe with the secret key
if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('Missing required Stripe secret: STRIPE_SECRET_KEY');
}
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

export async function registerRoutes(app: Express): Promise<Server> {
  // Serve static files from the public directory
  app.use(express.static('public'));
  
  // Configure multer for file uploads
  const upload = multer({
    dest: path.join(process.cwd(), 'uploads'),
    limits: {
      fileSize: 10 * 1024 * 1024, // 10MB limit
    },
    fileFilter: (_req, file, cb) => {
      // Accept only CSV files
      if (file.mimetype === 'text/csv' || file.originalname.endsWith('.csv')) {
        cb(null, true);
      } else {
        cb(new Error('Only CSV files are allowed'));
      }
    }
  });

  // Seed initial data if the database is empty
  await seedInitialData();
  
  // Get contact counts by stage - must be defined before the /:stage route to avoid being matched by it
  app.get("/api/contacts/counts", async (_req: Request, res: Response) => {
    const counts = await storage.getContactCounts();
    return res.json(counts);
  });
  
  // Endpoint to check for contacts due for stage progression
  app.get("/api/contacts/due-for-progression", async (_req: Request, res: Response) => {
    try {
      const contactsDue = await storage.getContactsDueForNextStage();
      
      return res.json({
        count: contactsDue.length,
        contacts: contactsDue
      });
    } catch (error) {
      console.error("Error checking contacts due for progression:", error);
      return res.status(500).json({ message: "Failed to check contacts due for progression" });
    }
  });
  
  // Endpoint to process contacts that are due for stage progression
  app.post("/api/contacts/process-progression", async (_req: Request, res: Response) => {
    try {
      const contactsDue = await storage.getContactsDueForNextStage();
      const results = [];
      
      // Process each contact due for progression
      for (const contact of contactsDue) {
        const updatedContact = await storage.moveContactToNextStage(contact.id);
        if (updatedContact) {
          results.push({
            id: contact.id,
            entityName: contact.entityName,
            primaryContact: contact.primaryContact,
            oldStage: contact.stage,
            newStage: updatedContact.stage
          });
        }
      }
      
      return res.json({
        processed: results.length,
        results
      });
    } catch (error) {
      console.error("Error processing contacts for progression:", error);
      return res.status(500).json({ message: "Failed to process contacts for progression" });
    }
  });

  // Get all contacts (for calendar and other aggregate views)
  app.get("/api/contacts/all", async (_req: Request, res: Response) => {
    try {
      // Get contacts without specifying a day to get all of them
      const contacts = await storage.getContacts();
      return res.json(contacts);
    } catch (error) {
      console.error("Error fetching all contacts:", error);
      return res.status(500).json({ message: "Failed to fetch all contacts" });
    }
  });

  // Get all contacts for a specific day
  app.get("/api/contacts/:day", async (req: Request, res: Response) => {
    const { day } = req.params;
    
    // Special case handled by the route above
    if (day === "all") {
      return res.status(400).json({ message: "Use the /api/contacts/all endpoint instead" });
    }
    
    // Validate day
    if (!Object.values(ContactDay).includes(day as ContactDay)) {
      return res.status(400).json({ message: "Invalid day parameter" });
    }
    
    const contacts = await storage.getContacts(day);
    return res.json(contacts);
  });

  // Create a new contact
  app.post("/api/contacts", async (req: Request, res: Response) => {
    try {
      console.log("Creating contact with data:", JSON.stringify(req.body, null, 2));
      const contact = contactSchema.parse(req.body);
      const newContact = await storage.createContact(contact);
      return res.status(201).json(newContact);
    } catch (error) {
      if (error instanceof z.ZodError) {
        console.error("Validation error creating contact:", JSON.stringify(error.errors, null, 2));
        return res.status(400).json({ 
          message: "Invalid contact data", 
          errors: error.errors 
        });
      }
      console.error("Error creating contact:", error);
      return res.status(500).json({ 
        message: "Failed to create contact" 
      });
    }
  });

  // Update a contact
  app.patch("/api/contacts/:id", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid contact ID" });
    }

    try {
      // Partial validation - only validate the fields that are provided
      const updateData = contactSchema.partial().parse(req.body);
      const updatedContact = await storage.updateContact(id, updateData);
      
      if (!updatedContact) {
        return res.status(404).json({ message: "Contact not found" });
      }
      
      return res.json(updatedContact);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid contact data", 
          errors: error.errors 
        });
      }
      return res.status(500).json({ 
        message: "Failed to update contact" 
      });
    }
  });

  // Update contact attempted status
  app.patch("/api/contacts/:id/attempted", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid contact ID" });
    }

    try {
      const { contactAttempted } = contactAttemptedSchema.parse(req.body);
      const updatedContact = await storage.updateContactAttempted(id, contactAttempted);
      
      if (!updatedContact) {
        return res.status(404).json({ message: "Contact not found" });
      }
      
      return res.json(updatedContact);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid data", 
          errors: error.errors 
        });
      }
      return res.status(500).json({ 
        message: "Failed to update contact status" 
      });
    }
  });

  // Delete a contact
  app.delete("/api/contacts/:id", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid contact ID" });
    }

    const success = await storage.deleteContact(id);
    if (!success) {
      return res.status(404).json({ message: "Contact not found" });
    }
    
    return res.status(204).end();
  });

  // Generate contact insights with OpenAI
  app.post("/api/contacts/:id/insights", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid contact ID" });
    }
    
    try {
      const contact = await storage.getContactById(id);
      if (!contact) {
        return res.status(404).json({ message: "Contact not found" });
      }
      
      // Convert null values to undefined to match the function signature
      const companyLinkedIn = contact.companyLinkedIn === null ? undefined : contact.companyLinkedIn;
      const contactLinkedIn = contact.contactLinkedIn === null ? undefined : contact.contactLinkedIn;
      const contactFacebook = contact.contactFacebook === null ? undefined : contact.contactFacebook;
      
      const insights = await generateContactInsights(
        contact.entityName,
        contact.primaryContact,
        companyLinkedIn,
        contactLinkedIn,
        contactFacebook
      );
      
      // Update the contact with the generated insights
      const updatedContact = await storage.updateContact(id, { 
        notes: insights 
      });
      
      return res.json(updatedContact);
    } catch (error) {
      console.error("Error generating insights:", error);
      return res.status(500).json({ 
        message: "Failed to generate insights" 
      });
    }
  });
  
  // Upload CSV file to populate contacts
  app.post("/api/contacts/upload-csv", upload.single('file'), async (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      
      const { day } = req.body;
      
      // Validate day
      if (!Object.values(ContactDay).includes(day as ContactDay)) {
        return res.status(400).json({ message: "Invalid day parameter" });
      }
      
      // Read the uploaded CSV file
      const fileContent = fs.readFileSync(req.file.path, 'utf8');
      
      // Parse the CSV data
      const records: any[] = await new Promise((resolve, reject) => {
        parse(fileContent, {
          columns: true,
          skip_empty_lines: true,
          trim: true,
        }, (err, records) => {
          if (err) reject(err);
          else resolve(records);
        });
      });
      
      // Process each row and create contacts
      const createdContacts = [];
      for (const record of records) {
        // Map CSV columns to contact fields - matching schema field names exactly
        const contact = {
          entityName: record.entityName || record['Entity Name'] || '',
          primaryContact: record.primaryContact || record['Primary Contact'] || '',
          emailAddress: record.emailAddress || record.email || record['Email Address'] || '',
          phoneNumber: record.phoneNumber || record.phone || record['Phone Number'] || '',
          companyLinkedIn: record.companyLinkedIn || record['Company LinkedIn Profile'] || '',
          contactLinkedIn: record.contactLinkedIn || record['Primary Contact LinkedIn Profile'] || '',
          contactFacebook: record.contactFacebook || record['Primary Contact Facebook Profile'] || '',
          notes: record.notes || record['Notes'] || '',
          contactAttempted: false,
          stage: ContactStage.FIRST_EMAIL,
          day: day as ContactDay,
          stageTransitionDate: null,
        };
        
        try {
          // Validate contact data (partial since not all fields are required)
          const validContact = contactSchema.parse(contact);
          const newContact = await storage.createContact(validContact);
          createdContacts.push(newContact);
        } catch (validationError) {
          // Log more details about the validation error
          if (validationError instanceof z.ZodError) {
            console.error('Validation error details:', JSON.stringify(validationError.errors, null, 2));
            console.error('Failed contact data:', JSON.stringify(contact, null, 2));
          } else {
            console.error('Non-validation error for CSV row:', validationError);
          }
          // Continue processing other rows
        }
      }
      
      // Delete the uploaded file
      fs.unlinkSync(req.file.path);
      
      return res.status(201).json({
        message: `Successfully imported ${createdContacts.length} contacts`,
        imported: createdContacts.length,
        total: records.length
      });
    } catch (err: any) {
      const error = err as Error;
      console.error("Error processing CSV file:", error);
      
      // Clean up the file if it exists
      if (req.file && fs.existsSync(req.file.path)) {
        fs.unlinkSync(req.file.path);
      }
      
      return res.status(500).json({ 
        message: "Failed to process CSV file",
        error: error.message
      });
    }
  });

  // Database reset endpoint - provides new users with a clean slate
  app.post("/api/debug/reseed", async (_req: Request, res: Response) => {
    try {
      // Import the reset function to avoid circular dependencies
      const { resetDatabase } = await import("./seed");
      const success = await resetDatabase();
      
      if (success) {
        return res.json({ 
          success: true, 
          message: "Database reset successfully. All contacts have been cleared and replaced with empty rows." 
        });
      } else {
        return res.status(500).json({ 
          success: false, 
          message: "Failed to reset database" 
        });
      }
    } catch (err: unknown) {
      const error = err as Error;
      console.error("Error resetting database:", error);
      return res.status(500).json({ 
        success: false, 
        message: "Failed to reset database" 
      });
    }
  });

  // Stripe checkout endpoint for one-time payment
  app.post("/api/create-checkout-session", async (req: Request, res: Response) => {
    try {
      // Default URL if origin is not available
      const baseUrl = req.headers.origin || 'https://cadenceiq.repl.co';
      
      const session = await stripe.checkout.sessions.create({
        payment_method_types: ['card'],
        line_items: [
          {
            price_data: {
              currency: 'usd',
              product_data: {
                name: 'CadenceIQ - Contact Management System',
                description: 'Full access to CadenceIQ contact management platform',
              },
              unit_amount: 995, // $9.95 in cents
            },
            quantity: 1,
          },
        ],
        mode: 'payment',
        // Collect customer email for sending access instructions
        customer_email: req.body.email, 
        // Pass email to success page via query parameter
        success_url: `${baseUrl}/success?email={CHECKOUT_SESSION_CUSTOMER_EMAIL}`,
        cancel_url: `${baseUrl}/`,
      });

      res.json({ url: session.url });
    } catch (error: any) {
      console.error('Error creating checkout session:', error);
      res.status(500).json({ 
        error: {
          message: error.message
        } 
      });
    }
  });
  
  // Send access link email
  app.post("/api/send-access-email", async (req: Request, res: Response) => {
    const { email } = req.body;
    
    if (!email) {
      return res.status(400).json({ 
        error: { message: "Email is required" } 
      });
    }
    
    try {
      // Import here to avoid loading SendGrid when not needed
      const { sendAccessEmail } = await import('./utils/sendgrid');
      
      // Generate the access URL
      const baseUrl = req.headers.origin || 'https://cadenceiq.repl.co';
      const accessUrl = `${baseUrl}/app`;
      
      // Send the access email
      const success = await sendAccessEmail(email, accessUrl);
      
      if (success) {
        res.json({ success: true, message: "Access email sent successfully" });
      } else {
        res.status(500).json({ 
          error: { message: "Failed to send access email" } 
        });
      }
    } catch (error: any) {
      console.error('Error sending access email:', error);
      res.status(500).json({ 
        error: { message: error.message } 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
