import { storage } from "./storage";
import { ContactStage, ContactDay, type InsertContact } from "@shared/schema";
import { log } from "./vite";

// Create empty row template function
const createEmptyRowsForDay = (day: ContactDay) => {
  // Using map instead of fill to create separate objects for each row
  // This prevents issues with reference copies when using fill with objects
  return Array(10).fill(null).map(() => ({
    entityName: "",
    primaryContact: "",
    emailAddress: "",
    phoneNumber: "",
    companyLinkedIn: null,
    contactLinkedIn: null,
    contactFacebook: null,
    notes: "",
    stage: ContactStage.FIRST_EMAIL, // All new contacts start at the first email stage
    contactAttempted: false,
    day: day,
    stageTransitionDate: null
  }));
};

/**
 * Seeds the database with empty rows if it's empty.
 * This ensures new users have a grid structure to start with.
 */
export async function seedInitialData(): Promise<void> {
  try {
    // Check if there's any data in the database
    const counts = await storage.getContactCounts();
    const totalContacts = Object.values(counts).reduce((sum, count) => sum + count, 0);
    
    // If there are no contacts, seed the database with empty rows
    if (totalContacts === 0) {
      log("No contacts found. Seeding database with empty rows for each day...");
      await createEmptyContactGrid();
    } else {
      log(`Database already contains ${totalContacts} contacts. Skipping seed.`);
    }
  } catch (error) {
    console.error("Error seeding initial data:", error);
  }
}

/**
 * Creates an empty contact grid with 10 rows for each weekday.
 * This can be used for initial seeding or for resetting the database.
 */
export async function createEmptyContactGrid(): Promise<number> {
  // Create and insert 10 empty rows for each day
  const days = [
    ContactDay.MONDAY,
    ContactDay.TUESDAY,
    ContactDay.WEDNESDAY,
    ContactDay.THURSDAY,
    ContactDay.FRIDAY
  ];
  
  let totalRowsCreated = 0;
  
  for (const day of days) {
    const emptyRows = createEmptyRowsForDay(day);
    for (const emptyRow of emptyRows) {
      await storage.createContact({...emptyRow} as InsertContact);
      totalRowsCreated++;
    }
  }
  
  log(`Successfully created ${totalRowsCreated} empty rows (10 for each weekday).`);
  return totalRowsCreated;
}

/**
 * Resets the database by deleting all contacts and creating a fresh empty grid.
 * Used to provide new users with a clean starting point.
 */
export async function resetDatabase(): Promise<boolean> {
  try {
    // Get all contacts
    const contacts = await storage.getContacts();
    
    // Delete all contacts
    for (const contact of contacts) {
      await storage.deleteContact(contact.id);
    }
    
    log(`Deleted all ${contacts.length} existing contacts.`);
    
    // Create fresh empty contact grid
    await createEmptyContactGrid();
    
    return true;
  } catch (error) {
    console.error("Error resetting database:", error);
    return false;
  }
}