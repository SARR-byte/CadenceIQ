import { pgTable, text, serial, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// The stage represents the email outreach stage
export enum ContactStage {
  FIRST_EMAIL = "FIRST_EMAIL",
  SECOND_EMAIL = "SECOND_EMAIL",
  PHONE_LINKEDIN = "PHONE_LINKEDIN",
  BREAKUP_EMAIL = "BREAKUP_EMAIL",
}

// The day represents which day the contact was initially added
export enum ContactDay {
  MONDAY = "MONDAY",
  TUESDAY = "TUESDAY",
  WEDNESDAY = "WEDNESDAY",
  THURSDAY = "THURSDAY",
  FRIDAY = "FRIDAY",
}

// User access level
export enum UserRole {
  FREE = "FREE",
  PAID = "PAID",
  ADMIN = "ADMIN",
}

export const contacts = pgTable("contacts", {
  id: serial("id").primaryKey(),
  entityName: text("entity_name").notNull(),
  primaryContact: text("primary_contact").notNull(),
  emailAddress: text("email_address").notNull(),
  phoneNumber: text("phone_number"),
  companyLinkedIn: text("company_linkedin"),
  contactLinkedIn: text("contact_linkedin"),
  contactFacebook: text("contact_facebook"),
  notes: text("notes"),
  contactAttempted: boolean("contact_attempted").notNull().default(false),
  stage: text("stage").notNull().default(ContactStage.FIRST_EMAIL),
  day: text("day").notNull().default(ContactDay.MONDAY),
  stageTransitionDate: timestamp("stage_transition_date", { mode: 'date' }),
});

// Schema for creating or updating a contact
export const contactSchema = createInsertSchema(contacts)
  .omit({ id: true })
  .extend({
    // Allow stageTransitionDate to be either a Date, a string that can be parsed as a date,
    // or null/undefined for creating new contacts without a transition date
    stageTransitionDate: z.union([
      z.date(),
      z.string().transform((str) => new Date(str)),
      z.null(),
      z.undefined()
    ])
  });

// Schema for updating just the contact attempted status
export const contactAttemptedSchema = z.object({
  contactAttempted: z.boolean(),
});

// User table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default(UserRole.FREE),
  stripeCustomerId: text("stripe_customer_id"),
  stripeSessionId: text("stripe_session_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Schema for creating a user
export const userSchema = createInsertSchema(users)
  .omit({ id: true, createdAt: true });

// Schema for login
export const loginSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof userSchema>;
export type LoginCredentials = z.infer<typeof loginSchema>;

export type Contact = typeof contacts.$inferSelect;
export type InsertContact = z.infer<typeof contactSchema>;
export type UpdateContactAttempted = z.infer<typeof contactAttemptedSchema>;
