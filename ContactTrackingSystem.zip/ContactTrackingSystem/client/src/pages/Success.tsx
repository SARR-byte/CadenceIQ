import { Link } from "wouter";
import { CheckCircle, Bookmark, ExternalLink } from "lucide-react";
import { useEffect, useState } from "react";

export default function Success() {
  const [showBookmarkTip, setShowBookmarkTip] = useState(false);
  
  // Auto-send email access reminder if email is available in URL params
  const [emailSent, setEmailSent] = useState(false);
  const [sendingEmail, setSendingEmail] = useState(false);
  const [emailAddress, setEmailAddress] = useState<string | null>(null);
  const [resettingDatabase, setResettingDatabase] = useState(false);
  const [databaseReset, setDatabaseReset] = useState(false);
  
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const email = urlParams.get('email');
    
    if (email) {
      setEmailAddress(email);
      sendAccessEmail(email);
    }
    
    // Reset the database for new users for a clean start
    resetDatabase();
  }, []);
  
  const sendAccessEmail = async (email: string) => {
    try {
      setSendingEmail(true);
      
      const response = await fetch('/api/send-access-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      });
      
      const data = await response.json();
      
      if (response.ok) {
        setEmailSent(true);
        console.log('Access email sent successfully');
      } else {
        console.error('Failed to send access email:', data.error);
      }
    } catch (error) {
      console.error('Error sending access email:', error);
    } finally {
      setSendingEmail(false);
    }
  };
  
  // Reset the database to provide a clean slate for new users
  const resetDatabase = async () => {
    try {
      setResettingDatabase(true);
      
      const response = await fetch('/api/debug/reseed', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      
      const data = await response.json();
      
      if (response.ok && data.success) {
        setDatabaseReset(true);
        console.log('Database reset successfully');
      } else {
        console.error('Failed to reset database:', data.message);
      }
    } catch (error) {
      console.error('Error resetting database:', error);
    } finally {
      setResettingDatabase(false);
    }
  };
  
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="max-w-lg w-full p-8 bg-white rounded-lg shadow-md text-center">
        <div className="flex justify-center mb-4">
          <div className="bg-green-100 p-3 rounded-full">
            <CheckCircle className="h-12 w-12 text-green-500" />
          </div>
        </div>
        
        <h1 className="text-2xl font-bold text-gray-800 mb-2">Payment Successful!</h1>
        <p className="text-gray-600 mb-6">
          Thank you for your purchase. You now have full access to CadenceIQ.
        </p>
        
        <div className="space-y-6">
          <Link 
            to="/app" 
            className="inline-block bg-[#333333] text-white px-8 py-4 rounded-md font-semibold hover:bg-gray-700 transition-colors text-lg w-full"
          >
            Go to Dashboard
          </Link>
          
          <div className="bg-blue-50 p-4 rounded-md text-left">
            <h3 className="font-semibold text-blue-800 flex items-center mb-2">
              <Bookmark className="h-5 w-5 mr-2" />
              Important: Save Your Access
            </h3>
            
            <p className="text-blue-700 mb-2">
              For easy access in the future, please bookmark this URL:
            </p>
            
            <div 
              className="bg-white p-3 rounded border border-blue-200 text-blue-800 font-mono text-sm flex justify-between items-center"
              onClick={() => {
                navigator.clipboard.writeText(window.location.origin + "/app");
                setShowBookmarkTip(true);
                setTimeout(() => setShowBookmarkTip(false), 3000);
              }}
            >
              <span>{window.location.origin}/app</span>
              <button className="text-blue-600 hover:text-blue-800">
                {showBookmarkTip ? "Copied!" : "Copy"}
              </button>
            </div>
            
            <p className="text-blue-700 mt-3 text-sm">
              You can access your CadenceIQ dashboard anytime by visiting this URL.
            </p>
            
            {emailAddress && (
              <div className="mt-4 pt-4 border-t border-blue-100">
                {sendingEmail ? (
                  <p className="text-blue-700 text-sm flex items-center">
                    <svg className="animate-spin h-4 w-4 mr-2 text-blue-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Sending access link to your email...
                  </p>
                ) : emailSent ? (
                  <p className="text-green-600 text-sm flex items-center">
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Access link sent to {emailAddress}
                  </p>
                ) : (
                  <p className="text-orange-600 text-sm flex items-center">
                    <ExternalLink className="h-4 w-4 mr-2" />
                    We couldn't send the access email automatically. Please bookmark this page.
                  </p>
                )}
              </div>
            )}
          </div>
        </div>
        
        <div className="mt-8 pt-6 border-t border-gray-200">
          <p className="text-sm text-gray-500 mb-2">
            Need help? Contact our support team at <a href="mailto:support@cadenceiq.co" className="text-blue-600 hover:underline">support@cadenceiq.co</a>
          </p>
          <p className="text-xs text-gray-400">
            Your purchase includes unlimited access to CadenceIQ.
          </p>
        </div>
      </div>
    </div>
  );
}