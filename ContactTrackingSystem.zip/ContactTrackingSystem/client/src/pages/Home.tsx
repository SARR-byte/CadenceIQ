import { useState, useMemo, useEffect } from "react";
import { TabNavigation } from "@/components/TabNavigation";
import { Toolbar } from "@/components/Toolbar";
import { ContactGrid } from "@/components/ContactGrid";
import { Notification } from "@/components/Notification";
import { Footer } from "@/components/Footer";
import { TestCelebration } from "@/components/TestCelebration";
import { useContacts, useNotification } from "@/lib/hooks";
import { emailValidator, phoneValidator, urlValidator } from "@/lib/validators";
import { ContactStage, ContactDay, Contact } from "@shared/schema";
import { NotesModal } from "../App";
import { RefreshCcw as RefreshCcwIcon } from "lucide-react";

export default function Home() {
  // State for the active day, active stage, and selected rows
  const [activeDay, setActiveDay] = useState<ContactDay>(ContactDay.MONDAY);
  const [activeStage, setActiveStage] = useState<ContactStage>(ContactStage.FIRST_EMAIL);
  const [selectedRows, setSelectedRows] = useState<number[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [allTasksComplete, setAllTasksComplete] = useState(false);

  // Get contacts for the current day
  const {
    contacts: allContacts,
    isLoading,
    error,
    createContact,
    updateContact,
    deleteContact,
    updateAttempted,
    generateInsights,
    isGeneratingInsights,
  } = useContacts(activeDay);

  // Notification system
  const { notification, showNotification, hideNotification } = useNotification();
  
  // Notes modal state
  const [activeNote, setActiveNote] = useState<string | null>(null);
  
  // Check if all contacts for the day have been attempted
  useEffect(() => {
    if (isLoading || !allContacts || allContacts.length === 0) return;
    
    // Check if there are any contacts in the current day, and all of them are attempted
    const nonAttemptedContacts = allContacts.filter((contact: Contact) => !contact.contactAttempted);
    
    // If there are contacts and all have been attempted, set all tasks complete
    if (allContacts.length > 0 && nonAttemptedContacts.length === 0) {
      setAllTasksComplete(true);
    } else {
      setAllTasksComplete(false);
    }
  }, [allContacts, isLoading]);

  // Filter contacts based on search query and active stage
  const filteredContacts = useMemo(() => {
    // Filter by stage - activeStage is never null now
    let contacts = allContacts.filter((contact: Contact) => contact.stage === activeStage);
    
    // Then, filter by search query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      contacts = contacts.filter(
        (contact: Contact) =>
          contact.entityName.toLowerCase().includes(query) ||
          contact.primaryContact.toLowerCase().includes(query) ||
          contact.emailAddress.toLowerCase().includes(query) ||
          (contact.phoneNumber && contact.phoneNumber.toLowerCase().includes(query))
      );
    }
    
    return contacts;
  }, [allContacts, activeStage, searchQuery]);

  // Handle day change
  const handleDayChange = (day: ContactDay) => {
    setActiveDay(day);
    setSelectedRows([]);
  };

  // Handle adding a new row
  const handleAddRow = (showNotificationMsg = true) => {
    // Create a new contact with empty fields in the First Email stage for the active day
    createContact({
      entityName: "",
      primaryContact: "",
      emailAddress: "",
      phoneNumber: null,
      companyLinkedIn: null,
      contactLinkedIn: null,
      contactFacebook: null,
      notes: null,
      stage: ContactStage.FIRST_EMAIL,
      contactAttempted: false,
      day: activeDay,
      stageTransitionDate: null
    });
    
    if (showNotificationMsg) {
      showNotification(`Added new contact to ${activeDay.toLowerCase()} in First Email stage`, "success");
    }
    
    return true; // Return success flag
  };
  
  // Function to add multiple rows at once
  const handleAddMultipleRows = (count: number) => {
    if (count <= 0) return;
    
    let addedCount = 0;
    for (let i = 0; i < count; i++) {
      if (handleAddRow(false)) {
        addedCount++;
      }
    }
    
    if (addedCount > 0) {
      showNotification(`Added ${addedCount} new contacts to ${activeDay.toLowerCase()} in First Email stage`, "success");
    }
  };
  
  // Reset database to initial state
  const handleResetDatabase = async () => {
    try {
      setIsLoading(true);
      
      const response = await fetch('/api/debug/reseed', {
        method: 'POST',
      });
      
      const data = await response.json();
      
      if (response.ok && data.success) {
        showNotification("Database reset successfully. All contacts have been cleared and replaced with empty rows.", "success");
        // Refetch contacts instead of reloading the page
        refetchContacts();
      } else {
        showNotification("Failed to reset database: " + (data.message || "Unknown error"), "error");
      }
    } catch (error) {
      console.error("Error resetting database:", error);
      showNotification("Error resetting database", "error");
    } finally {
      setIsLoading(false);
    }
  };

  // Handle deleting selected rows
  const handleDeleteSelected = () => {
    if (selectedRows.length === 0) return;
    
    // Delete each selected row
    selectedRows.forEach((id) => {
      deleteContact(id);
    });
    
    showNotification(`${selectedRows.length} contact(s) deleted`, "info");
    setSelectedRows([]);
  };

  // Handle value change in a cell
  const handleValueChange = (id: number, field: string, value: string) => {
    // Validate input based on field type
    try {
      if (field === 'emailAddress') {
        emailValidator.parse(value);
      } else if (field === 'phoneNumber') {
        phoneValidator.parse(value);
      } else if (['companyLinkedIn', 'contactLinkedIn', 'contactFacebook'].includes(field)) {
        urlValidator.parse(value);
      }
      
      // Update contact with new value
      updateContact({ 
        id, 
        data: { [field]: value } 
      });
    } catch (error) {
      // Revert the cell to its original value
      showNotification(`Invalid ${field.replace(/([A-Z])/g, ' $1').toLowerCase()}`, "error");
    }
  };

  // Handle contact attempted toggle
  const handleAttemptedChange = (id: number, attempted: boolean) => {
    updateAttempted({ id, attempted });
    
    if (attempted) {
      // Find the contact
      const contact = filteredContacts.find((c: Contact) => c.id === id);
      if (!contact) return;
      
      // Show different notification messages based on the contact's stage
      let nextStage = "";
      switch (contact.stage) {
        case ContactStage.FIRST_EMAIL:
          nextStage = "Second Email";
          break;
        case ContactStage.SECOND_EMAIL:
          nextStage = "Phone/LinkedIn Outreach";
          break;
        case ContactStage.PHONE_LINKEDIN:
          nextStage = "Breakup Email";
          break;
        case ContactStage.BREAKUP_EMAIL:
          // Last stage
          nextStage = "";
          break;
      }
      
      if (nextStage) {
        showNotification(`Contact marked as attempted. Will move to ${nextStage} stage.`, "success");
      } else {
        showNotification("Contact marked as attempted in the final stage.", "success");
      }
      
      // Check if all contacts for this day have been attempted now
      setTimeout(() => {
        const remainingContacts = allContacts.filter(
          (c: Contact) => 
            c.day === activeDay && 
            c.stage === activeStage && 
            !c.contactAttempted && 
            c.id !== id // Exclude the current contact since the UI might not have updated yet
        );
        
        if (remainingContacts.length === 0) {
          // All contacts have been attempted! Show celebration directly
          TestCelebration();
          showNotification("Great job! All contacts for this day are complete!", "success");
        }
      }, 500); // Short delay to allow the state to update
    }
  };

  // Handle search
  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };
  
  // Handle generating insights for a contact
  const handleGenerateInsights = (id: number) => {
    showNotification("Generating insights from profile data...", "info");
    
    // Store current scroll position before insights generation
    const scrollPosition = document.querySelector('.contacts-grid-container')?.scrollTop || 0;
    
    // TanStack Query mutations don't return promises by default unless explicitly handled
    generateInsights(id, {
      onSuccess: () => {
        showNotification("Contact insights generated successfully!", "success");
        // Restore scroll position after insights generation completes
        setTimeout(() => {
          const gridContainer = document.querySelector('.contacts-grid-container');
          if (gridContainer) {
            gridContainer.scrollTop = scrollPosition;
          }
        }, 50);
      },
      onError: (error: unknown) => {
        console.error("Failed to generate insights:", error);
        showNotification("Failed to generate insights. Please try again.", "error");
      }
    });
  };

  return (
    <div className="container mx-auto p-4 max-w-full">
      <header className="mb-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-semibold text-[hsl(var(--ms-blue-dark))] mb-2">
              
            </h1>
            <div className="text-[1.8rem] font-medium tracking-tight text-[hsl(var(--ms-blue-dark))]">
              Smart. Efficient. Outreach.
            </div>
          </div>
          <div className="flex space-x-2">
            <button
              className="bg-[#333333] hover:bg-[#222222] text-white px-4 py-2 rounded-md flex items-center text-sm font-semibold shadow-md"
              style={{ backgroundColor: '#333', color: 'white' }}
              onClick={() => {
                if (window.confirm("Are you sure you want to reset the database? This will remove all contacts and create 10 empty rows for each day.")) {
                  handleResetDatabase();
                }
              }}
            >
              <RefreshCcwIcon className="h-4 w-4 mr-1" />
              <span>Reset Database</span>
            </button>
          </div>
        </div>
      </header>

      {/* Notification area */}
      <Notification
        message={notification.message}
        type={notification.type}
        visible={notification.visible}
        onClose={hideNotification}
      />

      {/* Day navigation */}
      <TabNavigation 
        activeDay={activeDay} 
        onDayChange={handleDayChange} 
      />
      
      {/* Stage filter */}
      <div className="flex items-center mb-4">
        <label className="mr-2 text-sm font-medium">Filter by stage:</label>
        <select
          className="p-2 border rounded-md"
          value={activeStage}
          onChange={(e) => {
            const value = e.target.value;
            setActiveStage(value as ContactStage);
          }}
        >
          <option value={ContactStage.FIRST_EMAIL}>First Email</option>
          <option value={ContactStage.SECOND_EMAIL}>Second Email</option>
          <option value={ContactStage.PHONE_LINKEDIN}>Phone/LinkedIn</option>
          <option value={ContactStage.BREAKUP_EMAIL}>Breakup Email</option>
        </select>
      </div>

      {/* Action toolbar */}
      <Toolbar
        rowCount={filteredContacts.length}
        selectedRows={selectedRows}
        onAddRow={handleAddRow}
        onAddMultipleRows={handleAddMultipleRows}
        onDeleteSelected={handleDeleteSelected}
        onSearch={handleSearch}
      />

      {/* Contact grid */}
      <ContactGrid
        contacts={filteredContacts}
        stage={activeStage}
        isLoading={isLoading}
        onValueChange={handleValueChange}
        onAttemptedChange={handleAttemptedChange}
        onSelectionChange={setSelectedRows}
        onGenerateInsights={handleGenerateInsights}
        isGeneratingInsights={isGeneratingInsights}
        onViewNote={(note) => setActiveNote(note)}
      />

      {/* Footer with stats */}
      <Footer />
      
      {/* Notes modal */}
      <NotesModal
        note={activeNote}
        onClose={() => setActiveNote(null)}
      />
      
      {/* We're now using the direct TestCelebration function instead of this component approach */}
    </div>
  );
}
