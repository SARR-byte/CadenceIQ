import { Link } from "wouter";
import { useState } from "react";
import { CheckCircle2, Mail, CalendarRange, Zap, Users, ArrowRight } from "lucide-react";
import { apiRequest } from "../lib/queryClient";

export default function LandingPage() {
  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  
  const handleBuyNow = async () => {
    try {
      setIsLoading(true);
      
      // Include email in checkout data if provided
      const checkoutData = email ? { email } : {};
      
      console.log("Sending request to create checkout session...");
      const response = await apiRequest(
        "POST",
        "/api/create-checkout-session",
        checkoutData
      );
      
      console.log("Received response:", response);
      const data = await response.json();
      console.log("Response data:", data);
      
      if (!data.url) {
        throw new Error("No URL returned from checkout session creation");
      }
      
      // Open Stripe checkout in a new tab instead of redirecting
      console.log("Opening Stripe checkout in new tab:", data.url);
      window.open(data.url, '_blank');
    } catch (error) {
      console.error("Error creating checkout session:", error);
      alert("Something went wrong with the checkout process. Please try again later.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Hero Section */}
      <header className="bg-[#333333] text-white">
        <div className="container mx-auto py-6 px-4 md:px-6">
          <nav className="flex justify-between items-center mb-16">
            <div className="flex items-center">
              <img src="/cadenceIQ-logo.png" alt="CadenceIQ Logo" className="h-70 mr-2" />
            </div>
            <div className="flex items-center">
              <button
                onClick={handleBuyNow}
                disabled={isLoading}
                className="bg-white text-[#333333] px-4 py-2 rounded-md font-semibold text-sm hover:bg-gray-100 transition-colors"
              >
                {isLoading ? 'Loading...' : 'Buy Now'}
              </button>
            </div>
          </nav>

          <div className="flex flex-col md:flex-row items-center justify-between py-12">
            <div className="md:w-1/2 mb-8 md:mb-0">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-4">
                Smart. Efficient. Outreach.
              </h1>
              <p className="text-xl mb-6 text-gray-200 max-w-md">
                A simple yet powerful contact management system that helps you close more deals with less effort.
              </p>
              <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
                <button
                  onClick={handleBuyNow}
                  disabled={isLoading}
                  className="bg-white text-[#333333] px-6 py-3 rounded-md font-semibold hover:bg-gray-100 transition-colors text-center"
                >
                  {isLoading ? 'Loading...' : 'Try it for $9.95'}
                </button>
              </div>
            </div>
            <div className="md:w-1/2 flex justify-center">
              <div className="bg-white p-2 rounded-md shadow-xl w-full max-w-md">
                <img
                  src="/demo-screenshot.png"
                  alt="CadenceIQ Dashboard"
                  className="rounded w-full"
                  style={{ opacity: 0.9 }}
                />
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-[#333333] mb-4">Why CadenceIQ Works</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Our proven system helps you manage contacts across multiple stages, increasing your connection rate by up to 40%.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-gray-50 p-6 rounded-lg">
              <div className="text-[#333333] mb-4">
                <Mail className="w-10 h-10" />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-[#333333]">Multi-Stage Outreach</h3>
              <p className="text-gray-600">
                Automatically progress contacts through all 4 stages of outreach: First Email, Second Email, Phone/LinkedIn, and Breakup Email.
              </p>
            </div>

            <div className="bg-gray-50 p-6 rounded-lg">
              <div className="text-[#333333] mb-4">
                <Zap className="w-10 h-10" />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-[#333333]">Personalized Insights</h3>
              <p className="text-gray-600">
                Generate personalized messaging by scanning LinkedIn and Facebook profiles, proven to improve response rates by 34%.
              </p>
            </div>

            <div className="bg-gray-50 p-6 rounded-lg">
              <div className="text-[#333333] mb-4">
                <CalendarRange className="w-10 h-10" />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-[#333333]">Smart Calendar</h3>
              <p className="text-gray-600">
                Organize contacts by weekday and automatically schedule follow-ups to maintain perfect timing in your outreach.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-[#333333] mb-4">What Our Users Say</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Sales professionals love how CadenceIQ simplifies their outreach process while increasing results.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <p className="text-gray-600 mb-4">
                "CadenceIQ helped me increase my response rate by 27% in just two weeks. The personalized insights are a game-changer."
              </p>
              <div className="flex items-center">
                <div className="w-10 h-10 bg-gray-200 rounded-full mr-3"></div>
                <div>
                  <div className="font-semibold text-[#333333]">Sarah Johnson</div>
                  <div className="text-sm text-gray-500">Sales Manager, TechCorp</div>
                </div>
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-sm">
              <p className="text-gray-600 mb-4">
                "The weekday organization system is brilliant. I'm closing more deals and spending less time managing my contacts."
              </p>
              <div className="flex items-center">
                <div className="w-10 h-10 bg-gray-200 rounded-full mr-3"></div>
                <div>
                  <div className="font-semibold text-[#333333]">Michael Torres</div>
                  <div className="text-sm text-gray-500">Business Development, GrowthFirm</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Personalization Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-8 md:mb-0">
              <h2 className="text-3xl font-bold text-[#333333] mb-4">Personalized Messages That Convert</h2>
              <p className="text-gray-600 mb-6">
                Research shows personalized outreach generates 50% more responses than generic templates. CadenceIQ helps you:
              </p>
              <ul className="space-y-3">
                {[
                  "Analyze prospect profiles to find common interests",
                  "Discover relevant professional experiences to mention",
                  "Identify mutual connections for warmer introductions",
                  "Generate personalized icebreakers that resonate"
                ].map((item, index) => (
                  <li key={index} className="flex items-start">
                    <CheckCircle2 className="w-5 h-5 text-green-500 mr-2 mt-0.5" />
                    <span className="text-gray-700">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="md:w-1/2 md:pl-12">
              <div className="bg-gray-50 p-6 rounded-lg border border-gray-200">
                <h3 className="font-semibold text-[#333333] mb-3">Sample Personalized Outreach</h3>
                <div className="bg-white p-4 rounded border border-gray-200 mb-4">
                  <p className="text-gray-800 text-sm">
                    <strong>Subject:</strong> Your recent article on cloud migration strategies
                  </p>
                  <p className="text-gray-800 text-sm mt-2">
                    Hi Alex,
                  </p>
                  <p className="text-gray-800 text-sm mt-2">
                    I noticed your LinkedIn post about cloud migration challenges at enterprise companies. Having worked with similar projects at IBM, I thought you might be interested in how we helped reduce migration time by 40%.
                  </p>
                  <p className="text-gray-800 text-sm mt-2">
                    I also see we're both connected to Sarah Miller. Small world!
                  </p>
                  <p className="text-gray-800 text-sm mt-2">
                    Would you have 15 minutes to discuss how we might help with your upcoming migration?
                  </p>
                </div>
                <p className="text-sm text-gray-500 italic">
                  CadenceIQ identified the prospect's recent post, work history, and mutual connection to create this high-converting message.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-[#333333] mb-4">Simple, Transparent Pricing</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              No complex tiers. No ongoing fees. Just one low price for the complete CadenceIQ system.
            </p>
          </div>

          <div className="max-w-md mx-auto bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-8">
              <h3 className="text-2xl font-bold text-center text-[#333333] mb-4">Full Access</h3>
              <div className="text-center mb-6">
                <span className="text-5xl font-bold text-[#333333]">$9.95</span>
                <span className="text-gray-500 ml-2">one-time payment</span>
              </div>
              <ul className="space-y-3 mb-8">
                {[
                  "50-contact campaign management",
                  "Multi-stage email tracking",
                  "Personalized insights generator",
                  "Smart calendar integration",
                  "CSV import/export",
                  "Unlimited usage"
                ].map((feature, index) => (
                  <li key={index} className="flex items-center">
                    <CheckCircle2 className="w-5 h-5 text-green-500 mr-2" />
                    <span className="text-gray-700">{feature}</span>
                  </li>
                ))}
              </ul>
              <div className="space-y-4">
                <div className="relative">
                  <input
                    type="email"
                    placeholder="Your email address"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-gray-500"
                  />
                  <p className="text-xs text-gray-500 mt-1">We'll send your access link to this email</p>
                </div>
                <button 
                  onClick={handleBuyNow}
                  disabled={isLoading}
                  className="w-full bg-[#333333] text-white py-3 rounded-md font-semibold hover:bg-gray-700 transition-colors flex items-center justify-center"
                >
                  {isLoading ? 'Loading...' : 'Get Started'} {!isLoading && <ArrowRight className="ml-2 w-4 h-4" />}
                </button>
              </div>
              <p className="text-xs text-center text-gray-500 mt-4">
                Secure checkout. Instant access after purchase.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#333333] text-white py-12">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-6 md:mb-0">
              <div className="flex items-center mb-2">
                <img src="/cadenceIQ-logo.png" alt="CadenceIQ Logo" className="h-16 mr-2 invert" />
              </div>
              <p className="text-gray-400">Smart. Efficient. Outreach.</p>
            </div>
            <div className="flex flex-col items-center md:items-end">
              <div className="flex space-x-4 mb-4">
                <a href="#" className="text-gray-400 hover:text-white">
                  Privacy
                </a>
                <a href="#" className="text-gray-400 hover:text-white">
                  Terms
                </a>
                <a href="#" className="text-gray-400 hover:text-white">
                  Contact
                </a>
              </div>
              <p className="text-gray-400 text-sm">© 2025 CadenceIQ. All rights reserved.</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}