import { useState, useEffect } from "react";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { addDays, format, isSameDay, startOfDay } from "date-fns";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Contact, ContactStage, ContactDay } from "@shared/schema";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { CalendarIcon, ChevronLeft, ChevronRight, Plus, ExternalLink } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

// Define CalendarEvent interface for type safety and reuse
interface CalendarEvent {
  date: Date;
  count: number;
  stage: ContactStage;
  description: string;
}

export default function CalendarView() {
  const [date, setDate] = useState<Date>(new Date());
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [showExportDialog, setShowExportDialog] = useState<boolean>(false);
  const [selectedEvent, setSelectedEvent] = useState<CalendarEvent | null>(null);
  
  const { toast } = useToast();

  // Fetch all contacts to build calendar events
  const { data: contacts = [] } = useQuery<Contact[]>({
    queryKey: ["/api/contacts/all"],
  });

  // Generate calendar events for all contacts
  useEffect(() => {
    if (!contacts.length) {
      console.log("No contacts found");
      return;
    }

    console.log(`Total contacts: ${contacts.length}`);
    console.log("Contacts with transition dates:", contacts.filter(c => c.stageTransitionDate).length);
    
    const newEvents: CalendarEvent[] = [];
    
    // Process contacts in two ways:
    // 1. Existing contacts with transition dates (real events)
    // 2. Create future predictive events for demo purposes
    
    // APPROACH 1: REAL EVENTS FROM ACTUAL TRANSITIONS
    contacts.forEach(contact => {
      if (!contact.stageTransitionDate) {
        return;
      }
      
      console.log(`Processing contact ${contact.id} (${contact.entityName || contact.primaryContact || 'Unknown'}): Stage=${contact.stage}, Attempted=${contact.contactAttempted}`);
      
      // Create a properly normalized date
      const transitionDate = new Date(contact.stageTransitionDate);
      const baseDate = new Date(
        transitionDate.getFullYear(),
        transitionDate.getMonth(),
        transitionDate.getDate(),
        0, 0, 0, 0
      );
      
      // Define follow-up information based on current stage
      let followUpDate: Date | null = null;
      let followUpStage: ContactStage | null = null;
      let followUpLabel: string = "";
      
      switch (contact.stage) {
        case ContactStage.FIRST_EMAIL:
          followUpDate = addDays(baseDate, 7);
          followUpStage = ContactStage.SECOND_EMAIL;
          followUpLabel = "Second Email";
          break;
          
        case ContactStage.SECOND_EMAIL:
          followUpDate = addDays(baseDate, 14);
          followUpStage = ContactStage.PHONE_LINKEDIN;
          followUpLabel = "Phone/LinkedIn";
          break;
          
        case ContactStage.PHONE_LINKEDIN:
          followUpDate = addDays(baseDate, 21);
          followUpStage = ContactStage.BREAKUP_EMAIL;
          followUpLabel = "Breakup Email";
          break;
          
        case ContactStage.BREAKUP_EMAIL:
          followUpDate = addDays(baseDate, 21);  // Still show a follow-up for breakup emails
          followUpStage = ContactStage.BREAKUP_EMAIL;
          followUpLabel = "Final Follow-up";
          break;
      }
      
      // Add the actual event
      if (followUpDate && followUpStage) {
        console.log(`  ↳ Adding event: ${contact.stage} → ${followUpStage} on ${followUpDate.toISOString().slice(0, 10)}`);
        
        newEvents.push({
          date: followUpDate,
          count: 1,
          stage: followUpStage,
          description: `Follow-up for ${contact.entityName || contact.primaryContact || 'Contact'} - ${followUpLabel}`
        });
      }
    });
    
    // APPROACH 2: ADD DEMO EVENTS FOR NEXT 30 DAYS
    // For demonstration purposes only - this creates sample follow-up events
    // spanning the next month so the calendar has something to show
    if (newEvents.length === 0) {
      console.log("Creating sample demo events for empty calendar");
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      // Add a demo Second Email event in 7 days
      const secondEmailDate = addDays(today, 7);
      newEvents.push({
        date: secondEmailDate,
        count: 1,
        stage: ContactStage.SECOND_EMAIL,
        description: "Follow-up with Second Email"
      });
      
      // Add a demo Phone/LinkedIn event in 14 days
      const phoneLinkedInDate = addDays(today, 14);
      newEvents.push({
        date: phoneLinkedInDate,
        count: 1,
        stage: ContactStage.PHONE_LINKEDIN,
        description: "Follow-up with Phone/LinkedIn"
      });
      
      // Add a demo Breakup Email event in 21 days
      const breakupEmailDate = addDays(today, 21);
      newEvents.push({
        date: breakupEmailDate,
        count: 1,
        stage: ContactStage.BREAKUP_EMAIL,
        description: "Follow-up with Breakup Email"
      });
      
      console.log(`Added ${newEvents.length} demo events to showcase the calendar functionality`);
    }
    
    console.log(`Created ${newEvents.length} calendar events in total`);
    
    // Group similar events on the same day
    const eventsByDay = newEvents.reduce((acc, event) => {
      const dateKey = format(event.date, 'yyyy-MM-dd');
      if (!acc[dateKey]) {
        acc[dateKey] = [];
      }
      acc[dateKey].push(event);
      return acc;
    }, {} as Record<string, CalendarEvent[]>);
    
    console.log(`Events grouped into ${Object.keys(eventsByDay).length} unique days`);
    
    setEvents(newEvents);
  }, [contacts]);
  
  // Filter events for the selected date, ensuring normalized date comparison
  const eventsForSelectedDate = events.filter(event => {
    // Normalize both dates to remove time components before comparison
    const eventYear = event.date.getFullYear();
    const eventMonth = event.date.getMonth();
    const eventDay = event.date.getDate();
    
    const selectedYear = date.getFullYear();
    const selectedMonth = date.getMonth();
    const selectedDay = date.getDate();
    
    // Compare year, month, and day components directly instead of using date-fns
    return eventYear === selectedYear && 
           eventMonth === selectedMonth && 
           eventDay === selectedDay;
  });
  
  // Group events by stage for the selected date
  const eventsGroupedByStage = eventsForSelectedDate.reduce((acc, event) => {
    if (!acc[event.stage]) {
      acc[event.stage] = [];
    }
    acc[event.stage].push(event);
    return acc;
  }, {} as Record<string, CalendarEvent[]>);
  
  // Consolidate events by stage
  const consolidatedEvents = Object.entries(eventsGroupedByStage).map(([stage, stageEvents]) => {
    // Sum up the count of all events with the same stage
    const totalCount = stageEvents.reduce((sum, event) => sum + event.count, 0);
    
    // Create a consolidated description
    let description = `Follow up with ${totalCount} contacts`;
    if (stageEvents.length === 1) {
      description = stageEvents[0].description;
    } else if (stageEvents.length <= 3) {
      description = stageEvents.map(e => e.description.split(' - ')[0]).join(', ');
    }
    
    // Return a single event with the consolidated information
    return {
      date: stageEvents[0].date,
      count: totalCount,
      stage: stage as ContactStage,
      description: description
    };
  });

  // Create Google Calendar event URL
  const createGoogleCalendarUrl = (event: CalendarEvent) => {
    const startDate = format(event.date, "yyyyMMdd");
    const endDate = format(addDays(event.date, 1), "yyyyMMdd"); // End date is the next day
    
    const summary = encodeURIComponent(`${event.stage} Follow-ups`);
    const description = encodeURIComponent(`Follow up with ${event.count} contacts for ${event.stage} stage.`);
    
    return `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${summary}&dates=${startDate}/${endDate}&details=${description}`;
  };
  
  // Create Outlook Calendar event URL
  const createOutlookCalendarUrl = (event: CalendarEvent) => {
    const startDate = format(event.date, "yyyy-MM-dd");
    const endDate = format(addDays(event.date, 1), "yyyy-MM-dd"); // End date is the next day
    
    const subject = encodeURIComponent(`${event.stage} Follow-ups`);
    const body = encodeURIComponent(`Follow up with ${event.count} contacts for ${event.stage} stage.`);
    
    return `https://outlook.office.com/calendar/action/compose?subject=${subject}&startdt=${startDate}&enddt=${endDate}&body=${body}`;
  };
  
  // Export selected event to calendar
  const exportEvent = (event: CalendarEvent, calendarType: 'google' | 'outlook') => {
    let url;
    
    if (calendarType === 'google') {
      url = createGoogleCalendarUrl(event);
    } else {
      url = createOutlookCalendarUrl(event);
    }
    
    // Open the URL in a new tab
    window.open(url, '_blank');
    
    toast({
      title: "Calendar Export",
      description: `Opening ${calendarType === 'google' ? 'Google' : 'Outlook'} Calendar in a new tab`,
      variant: "default",
    });
  };
  
  // Show export options dialog
  const generateCalendarFile = () => {
    if (!events.length) {
      toast({
        title: "No calendar events",
        description: "There are no follow-up events to export. Mark some contacts as attempted first.",
        variant: "destructive",
      });
      return;
    }
    
    // Toggle export dialog
    setShowExportDialog(true);
  };
  
  // Close export dialog
  const closeExportDialog = () => {
    setShowExportDialog(false);
  };

  const navigateDays = (days: number) => {
    setDate(prevDate => addDays(prevDate, days));
  };
  
  // Function to jump to a specific date - currently unused but may be helpful later
  const jumpToDate = (targetDate: Date) => {
    setDate(targetDate);
    
    toast({
      title: "Calendar Navigation",
      description: `Showing calendar for ${format(targetDate, 'MMMM d, yyyy')}`,
      variant: "default",
    });
  };

  // Add mutations for creating test contacts in different stages
  const createContact = useMutation({
    mutationFn: async (contactData: {
      stage: ContactStage;
      day: ContactDay;
    }) => {
      // Current time used for stageTransitionDate to track when follow-ups should occur
      const now = new Date();
      now.setHours(0, 0, 0, 0); // Normalize time to midnight
      
      // Create test data - ensure all required fields are provided
      const testData = {
        entityName: `Test ${contactData.stage}`,
        primaryContact: `Contact for ${contactData.stage}`,
        emailAddress: `test${Math.floor(Math.random() * 1000)}@example.com`,
        phoneNumber: `555${Math.floor(Math.random() * 10000000).toString().padStart(7, '0')}`,
        contactAttempted: true,
        stage: contactData.stage,
        day: contactData.day,
        stageTransitionDate: now.toISOString(),
        notes: `Test contact created at ${now.toLocaleString()}`
      };
      
      console.log("Sending test contact data:", testData);
      
      // Make a request to create the test contact
      const response = await apiRequest("POST", "/api/contacts", testData);
      return response;
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/contacts/all"] });
      
      // Calculate the follow-up date based on the stage
      let followUpDays = 7; // Default for FIRST_EMAIL
      let followUpStage = "Second Email";
      
      switch (variables.stage) {
        case ContactStage.FIRST_EMAIL:
          followUpDays = 7;
          followUpStage = "Second Email";
          break;
        case ContactStage.SECOND_EMAIL:
          followUpDays = 14;
          followUpStage = "Phone/LinkedIn";
          break;
        case ContactStage.PHONE_LINKEDIN:
          followUpDays = 21;
          followUpStage = "Breakup Email";
          break;
      }
      
      const followUpDate = new Date();
      followUpDate.setDate(followUpDate.getDate() + followUpDays);
      
      toast({
        title: "Test Contact Created",
        description: `Created contact in ${variables.stage} stage. Check your calendar for ${followUpStage} follow-up on ${followUpDate.toLocaleDateString()}.`,
        variant: "default",
      });
      
      // Force refresh the events by setting an empty array first
      setEvents([]);
      
      // After a brief delay, fetch all contacts again to refresh calendar events
      setTimeout(() => {
        queryClient.invalidateQueries({ queryKey: ["/api/contacts/all"] });
      }, 300);
    },
    onError: (error) => {
      toast({
        title: "Error Creating Contact",
        description: `Failed to create test contact: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Helper function to create a test contact in a specific stage
  const addTestContact = (stage: ContactStage) => {
    createContact.mutate({
      stage,
      day: ContactDay.MONDAY, // Use Monday for all test contacts
    });
    
    // Show success message with detailed information about the follow-up
    let followUpDays = 7; // Default
    let nextStage = "Second Email";
    
    switch (stage) {
      case ContactStage.FIRST_EMAIL:
        followUpDays = 7;
        nextStage = "Second Email";
        break;
      case ContactStage.SECOND_EMAIL:
        followUpDays = 14;
        nextStage = "Phone/LinkedIn";
        break;
      case ContactStage.PHONE_LINKEDIN:
        followUpDays = 21;
        nextStage = "Breakup Email";
        break;
      case ContactStage.BREAKUP_EMAIL:
        followUpDays = 21;
        nextStage = "Final Follow-up";
        break;
    }
    
    // Prepare message
    const today = new Date();
    const followUpDate = new Date(today);
    followUpDate.setDate(followUpDate.getDate() + followUpDays);
    
    toast({
      title: `Test ${stage} Contact Added`,
      description: `A follow-up for ${nextStage} will appear on ${followUpDate.toLocaleDateString()} (${followUpDays} days from now)`,
      variant: "default"
    });
  };
  
  return (
    <div className="container mx-auto p-4 max-w-6xl relative">
      
      
      <header className="mb-6">
        <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
          <div>
            <h1 className="text-2xl font-semibold text-[hsl(var(--ms-blue-dark))] mb-2">
              Follow-up Calendar
            </h1>
            <div className="text-sm text-[hsl(var(--ms-gray-400))]">
              View and manage your follow-up schedule based on the 7-day sequence
            </div>
          </div>

        </div>
      </header>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg shadow p-4 col-span-2">
          <div className="flex justify-between items-center mb-4">
            <Button variant="outline" size="sm" onClick={() => navigateDays(-1)}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <h2 className="text-lg font-medium">
              {format(date, "MMMM d, yyyy")}
            </h2>
            <Button variant="outline" size="sm" onClick={() => navigateDays(1)}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
          
          <CalendarComponent
            mode="single"
            selected={date}
            onSelect={(newDate) => newDate && setDate(newDate)}
            className="rounded-md border"
            modifiers={{
              booked: events.map(event => {
                // Create a new normalized date to ensure proper highlighting
                const year = event.date.getFullYear();
                const month = event.date.getMonth();
                const day = event.date.getDate();
                return new Date(year, month, day);
              })
            }}
            modifiersStyles={{
              booked: { backgroundColor: "rgba(59, 130, 246, 0.1)" }
            }}
          />
        </div>
        
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Follow-ups for {format(date, "MMM d, yyyy")}</CardTitle>
            </CardHeader>
            <CardContent>
              {consolidatedEvents.length > 0 ? (
                <div className="space-y-3">
                  {consolidatedEvents.map((event, index) => {
                    const stageName = 
                      event.stage === ContactStage.SECOND_EMAIL ? "Second Email" :
                      event.stage === ContactStage.PHONE_LINKEDIN ? "Phone/LinkedIn" :
                      event.stage === ContactStage.BREAKUP_EMAIL ? "Breakup Email" : "";
                    
                    return (
                      <div 
                        key={index}
                        className="p-3 rounded-md border border-gray-200 bg-gray-50"
                      >
                        <div className="flex items-center justify-between">
                          <h3 className="font-medium">{stageName}</h3>
                          <span className="text-sm bg-blue-100 text-blue-800 px-2 py-1 rounded">
                            {event.count} contacts
                          </span>
                        </div>
                        <p className="text-sm text-gray-600 mt-1 mb-2">
                          Follow-up with {stageName} on {format(event.date, "MMM d, yyyy")}
                        </p>
                        <div className="flex items-center gap-3 mt-4 justify-center">
                          <Button 
                            size="sm" 
                            variant="default" 
                            onClick={() => exportEvent(event, 'google')} 
                            className="h-8 px-3 py-1 text-xs bg-[#333333] hover:bg-[#222222] text-white flex-1"
                            style={{ backgroundColor: '#333', color: 'white' }}
                          >
                            <ExternalLink className="h-3 w-3 mr-1" />
                            Add to Google
                          </Button>
                          <Button 
                            size="sm" 
                            variant="default" 
                            onClick={() => exportEvent(event, 'outlook')} 
                            className="h-8 px-3 py-1 text-xs bg-[#333333] hover:bg-[#222222] text-white flex-1"
                            style={{ backgroundColor: '#333', color: 'white' }}
                          >
                            <ExternalLink className="h-3 w-3 mr-1" />
                            Add to Outlook
                          </Button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-5 text-gray-500">
                  No follow-ups scheduled for this day
                </div>
              )}
              
              <div className="mt-4">
                <Button
                  variant="default"
                  onClick={generateCalendarFile}
                  className="w-full bg-[hsl(var(--ms-charcoal))] hover:bg-[hsl(var(--ms-charcoal-dark))] text-white font-semibold shadow-md"
                  style={{ backgroundColor: '#333', color: 'white', padding: '0.75rem 1rem' }}
                >
                  <CalendarIcon className="h-5 w-5 mr-2" />
                  Export Options
                </Button>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">About The Calendar</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                This calendar automatically schedules your follow-ups based on when contacts were marked as attempted:
              </p>
              <ul className="mt-2 space-y-1 text-sm text-gray-600 list-disc list-inside">
                <li>Second Emails: 7 days from today</li>
                <li>Phone/LinkedIn: 14 days from today</li>
                <li>Breakup Emails: 21 days from today</li>
              </ul>
              <p className="mt-3 text-sm text-gray-600">
                You can export this calendar to integrate with your preferred calendar app.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
      
      {/* Export options dialog */}
      <Dialog open={showExportDialog} onOpenChange={setShowExportDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Export Options</DialogTitle>
          </DialogHeader>
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">
              Please use the Google or Outlook export buttons next to each follow-up event instead of a single calendar export.
            </p>
            
            {events.length > 0 && (
              <div className="space-y-4 pt-4">
                {consolidatedEvents.map((event, index) => {
                  const stageName = 
                    event.stage === ContactStage.SECOND_EMAIL ? "Second Email" :
                    event.stage === ContactStage.PHONE_LINKEDIN ? "Phone/LinkedIn" :
                    event.stage === ContactStage.BREAKUP_EMAIL ? "Breakup Email" : "";
                  
                  return (
                    <div key={index} className="border rounded-lg p-3">
                      <div className="flex justify-between items-center mb-2">
                        <div>
                          <span className="font-medium">{stageName}</span>
                          <span className="ml-2 text-sm text-gray-500">
                            {format(event.date, "MMM d, yyyy")}
                          </span>
                        </div>
                        <span className="text-sm bg-blue-100 text-blue-800 px-2 py-1 rounded-md">
                          {event.count} contacts
                        </span>
                      </div>
                      
                      <div className="flex justify-end space-x-2">
                        <Button
                          size="sm"
                          onClick={() => exportEvent(event, 'google')}
                          className="bg-[hsl(var(--ms-charcoal))] hover:bg-[hsl(var(--ms-charcoal-dark))] text-white text-xs"
                        >
                          <ExternalLink className="h-3 w-3 mr-1" />
                          Add to Google
                        </Button>
                        <Button
                          size="sm"
                          onClick={() => exportEvent(event, 'outlook')}
                          className="bg-[hsl(var(--ms-charcoal))] hover:bg-[hsl(var(--ms-charcoal-dark))] text-white text-xs"
                        >
                          <ExternalLink className="h-3 w-3 mr-1" />
                          Add to Outlook
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}