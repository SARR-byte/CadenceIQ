import { z } from "zod";

export const emailValidator = z
  .string()
  .email("Invalid email address")
  .max(255, "Email is too long");

export const phoneValidator = z
  .string()
  .regex(
    /^(\+\d{1,3}[ -]?)?\(?\d{3}\)?[ -]?\d{3}[ -]?\d{4}$/,
    "Invalid phone number format"
  )
  .optional()
  .or(z.literal(""));

export const urlValidator = z
  .string()
  .regex(
    /^(https?:\/\/)?(www\.)?([a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)+)(\/[a-zA-Z0-9-._~:/?#[\]@!$&'()*+,;=]*)?$/,
    "Invalid URL format"
  )
  .optional()
  .or(z.literal(""));
