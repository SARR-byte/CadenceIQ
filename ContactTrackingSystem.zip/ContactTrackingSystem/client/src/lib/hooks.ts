import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "./queryClient";
import { ContactDay, ContactStage, type Contact } from "@shared/schema";

export function useContacts(day: ContactDay) {
  const queryClient = useQueryClient();
  
  // Fetch contacts for the given day
  const {
    data: contacts = [] as Contact[],
    isLoading,
    error,
  } = useQuery<Contact[]>({
    queryKey: [`/api/contacts/${day}`],
  });

  // Create a new contact
  const createContactMutation = useMutation({
    mutationFn: (newContact: Omit<Contact, "id">) => {
      return apiRequest("POST", "/api/contacts", newContact);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/contacts/${day}`] });
      queryClient.invalidateQueries({ queryKey: ["/api/contacts/counts"] });
    },
  });

  // Update a contact
  const updateContactMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: Partial<Contact> }) => {
      return apiRequest("PATCH", `/api/contacts/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/contacts/${day}`] });
    },
  });

  // Delete a contact
  const deleteContactMutation = useMutation({
    mutationFn: (id: number) => {
      return apiRequest("DELETE", `/api/contacts/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/contacts/${day}`] });
      queryClient.invalidateQueries({ queryKey: ["/api/contacts/counts"] });
    },
  });

  // Update the contact attempted status
  const updateAttemptedMutation = useMutation({
    mutationFn: ({ id, attempted }: { id: number; attempted: boolean }) => {
      return apiRequest("PATCH", `/api/contacts/${id}/attempted`, { contactAttempted: attempted });
    },
    onSuccess: () => {
      // Invalidate all days since contacts can change across days
      Object.values(ContactDay).forEach((day) => {
        queryClient.invalidateQueries({ queryKey: [`/api/contacts/${day}`] });
      });
      queryClient.invalidateQueries({ queryKey: ["/api/contacts/counts"] });
    },
  });

  // Generate insights for a contact
  const generateInsightsMutation = useMutation({
    mutationFn: (id: number) => {
      return apiRequest("POST", `/api/contacts/${id}/insights`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/contacts/${day}`] });
    },
    onError: (error) => {
      console.error("Error generating insights:", error);
    },
  });

  return {
    contacts,
    isLoading,
    error,
    createContact: createContactMutation.mutate,
    updateContact: updateContactMutation.mutate,
    deleteContact: deleteContactMutation.mutate,
    updateAttempted: updateAttemptedMutation.mutate,
    generateInsights: generateInsightsMutation.mutate as any,
    isCreating: createContactMutation.isPending,
    isUpdating: updateContactMutation.isPending,
    isDeleting: deleteContactMutation.isPending,
    isUpdatingAttempted: updateAttemptedMutation.isPending,
    isGeneratingInsights: generateInsightsMutation.isPending,
  };
}

export function useContactCounts() {
  return useQuery({
    queryKey: ["/api/contacts/counts"],
  });
}

export function useNotification() {
  const [notification, setNotification] = useState<{
    message: string;
    type: "success" | "error" | "info";
    visible: boolean;
  }>({
    message: "",
    type: "info",
    visible: false,
  });

  const showNotification = (message: string, type: "success" | "error" | "info" = "info") => {
    setNotification({
      message,
      type,
      visible: true,
    });
  };

  const hideNotification = () => {
    setNotification((prev) => ({ ...prev, visible: false }));
  };

  useEffect(() => {
    let timer: number;
    
    if (notification.visible) {
      timer = window.setTimeout(() => {
        hideNotification();
      }, 3000);
    }
    
    return () => clearTimeout(timer);
  }, [notification.visible]);

  return {
    notification,
    showNotification,
    hideNotification,
  };
}
