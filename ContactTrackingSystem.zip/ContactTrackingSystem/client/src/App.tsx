import { Switch, Route, Link, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import Calendar from "@/pages/Calendar";
import LandingPage from "@/pages/LandingPage";
import Success from "@/pages/Success";
import { CalendarIcon, TableIcon, RefreshCcw as RefreshCcwIcon, X as XIcon } from "lucide-react";
import { createContext, useState, useCallback, useEffect, useContext } from "react";

// Global modal for notes display
export const NotesModal = ({ note, onClose }: { note: string | null; onClose: () => void }) => {
  if (!note) return null;
  
  // Close on escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [onClose]);
  
  // Close on backdrop click
  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };
  
  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50"
      onClick={handleBackdropClick}
    >
      <div 
        className="bg-white rounded-lg shadow-xl p-6 w-[600px] max-w-[90vw] max-h-[80vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center border-b pb-2 mb-4">
          <h3 className="text-xl font-bold text-blue-600">Notes</h3>
          <button 
            className="text-gray-500 hover:text-gray-800"
            onClick={onClose}
          >
            <XIcon className="h-6 w-6" />
          </button>
        </div>
        <div className="text-gray-800 text-lg whitespace-pre-wrap">
          {note}
        </div>
        <div className="mt-6 flex justify-end">
          <button 
            className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors"
            onClick={onClose}
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

// Global state for notes modal
export const useNotesModal = () => {
  const [activeNote, setActiveNote] = useState<string | null>(null);
  
  const openNote = useCallback((note: string) => {
    setActiveNote(note);
  }, []);
  
  const closeNote = useCallback(() => {
    setActiveNote(null);
  }, []);
  
  return {
    activeNote,
    openNote,
    closeNote
  };
};

// Create context for the notes modal
export const NotesModalContext = createContext<ReturnType<typeof useNotesModal> | null>(null);

// Hook to use the notes modal context
export const useNotesModalContext = () => {
  const context = useContext(NotesModalContext);
  if (!context) {
    throw new Error("useNotesModalContext must be used within a NotesModalProvider");
  }
  return context;
};

function AppNavigation() {
  return (
    <div className="bg-white border-b border-[hsl(var(--gray-300))] mb-4 sticky top-0 z-10 shadow-sm">
      <div className="container mx-auto flex justify-between items-center py-2">
        <Link href="/app" className="flex items-center">
          <img src="/cadenceIQ-logo.png" alt="CadenceIQ Logo" className="h-80" />
        </Link>
        <div className="flex items-center space-x-4">
          <Link href="/app" className="flex items-center gap-2 px-4 py-2 rounded-md bg-[#333333] hover:bg-[#222222] text-white shadow-md transition-colors" style={{ backgroundColor: '#333', color: 'white' }}>
            <TableIcon className="h-4 w-4" />
            <span>Contact Grid</span>
          </Link>
          <Link href="/app/calendar" className="flex items-center gap-2 px-4 py-2 rounded-md bg-[#333333] hover:bg-[#222222] text-white shadow-md transition-colors" style={{ backgroundColor: '#333', color: 'white' }}>
            <CalendarIcon className="h-4 w-4" />
            <span>Follow-up Calendar</span>
          </Link>
        </div>
      </div>
    </div>
  );
}

function Router() {
  const [location] = useLocation();
  const showNavigation = location.startsWith('/app');

  return (
    <>
      {showNavigation && <AppNavigation />}
      <Switch>
        <Route path="/" component={LandingPage} />
        <Route path="/app" component={Home} />
        <Route path="/app/calendar" component={Calendar} />
        <Route path="/success" component={Success} />
        <Route component={NotFound} />
      </Switch>
    </>
  );
}

function App() {
  const notesModal = useNotesModal();
  
  return (
    <QueryClientProvider client={queryClient}>
      <NotesModalContext.Provider value={notesModal}>
        <TooltipProvider>
          <Toaster />
          <Router />
          <NotesModal 
            note={notesModal.activeNote} 
            onClose={notesModal.closeNote} 
          />
        </TooltipProvider>
      </NotesModalContext.Provider>
    </QueryClientProvider>
  );
}

export default App;
