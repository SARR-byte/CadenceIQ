import { useEffect, useState } from 'react';
import confetti from 'canvas-confetti';

interface CelebrationProps {
  trigger: boolean;
  onComplete?: () => void;
}

export function Celebration({ trigger, onComplete }: CelebrationProps) {
  const [isActive, setIsActive] = useState(false);

  useEffect(() => {
    if (trigger && !isActive) {
      console.log("Celebration triggered!");
      setIsActive(true);
      
      // Configure celebration
      const duration = 5 * 1000; // 5 seconds
      const animationEnd = Date.now() + duration;
      
      // Create and show congratulatory message
      const message = document.createElement('div');
      message.className = 'fixed inset-0 flex items-center justify-center z-50 pointer-events-none';
      message.innerHTML = `
        <div class="bg-gradient-to-r from-indigo-600 to-blue-500 text-white px-10 py-8 rounded-lg shadow-xl transform scale-125 animate-bounce">
          <h2 class="text-4xl font-bold mb-3 text-center">Great Job! 🎉</h2>
          <p class="text-2xl text-center">All contacts for this day have been contacted!</p>
          <div class="mt-4 flex justify-center">
            <span class="inline-block bg-white text-indigo-600 px-4 py-2 rounded-full font-semibold text-lg">Keep up the good work!</span>
          </div>
        </div>
      `;
      document.body.appendChild(message);
      
      // Immediate confetti burst
      const fireConfetti = () => {
        // Burst from left
        confetti({
          particleCount: 50,
          angle: 60,
          spread: 55,
          origin: { x: 0, y: 0.7 },
          colors: ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'],
          shapes: ['circle', 'square'],
          ticks: 200
        });
        
        // Burst from right
        confetti({
          particleCount: 50,
          angle: 120,
          spread: 55,
          origin: { x: 1, y: 0.7 },
          colors: ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'],
          shapes: ['circle', 'square'],
          ticks: 200
        });
        
        // Burst from center
        confetti({
          particleCount: 100,
          angle: 90,
          spread: 100,
          origin: { x: 0.5, y: 0.5 },
          colors: ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'],
          shapes: ['circle', 'square'],
          ticks: 200
        });
      };
      
      // Fire confetti immediately
      fireConfetti();
      
      // Set up interval for continued confetti
      const interval = setInterval(() => {
        const timeLeft = animationEnd - Date.now();
        
        if (timeLeft <= 0) {
          clearInterval(interval);
          setIsActive(false);
          if (document.body.contains(message)) {
            document.body.removeChild(message);
          }
          if (onComplete) onComplete();
          return;
        }
        
        // Continue firing confetti
        fireConfetti();
      }, 700);
      
      return () => {
        clearInterval(interval);
        if (document.body.contains(message)) {
          document.body.removeChild(message);
        }
      };
    }
  }, [trigger, isActive, onComplete]);
  
  // This component doesn't render any visible elements directly
  return null;
}