import { useEffect } from "react";
import { AlertCircle, CheckCircle, Info } from "lucide-react";

interface NotificationProps {
  message: string;
  type: "success" | "error" | "info";
  visible: boolean;
  onClose: () => void;
}

export function Notification({ message, type, visible, onClose }: NotificationProps) {
  useEffect(() => {
    if (visible) {
      const timer = setTimeout(() => {
        onClose();
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [visible, onClose]);

  if (!visible) return null;

  const bgColor = 
    type === "success" ? "bg-green-100 border-green-500 text-green-700" :
    type === "error" ? "bg-red-100 border-red-500 text-red-700" :
    "bg-blue-100 border-blue-500 text-blue-700";

  const Icon = 
    type === "success" ? CheckCircle :
    type === "error" ? AlertCircle :
    Info;

  return (
    <div className={`${bgColor} border-l-4 p-4 mb-4 rounded`}>
      <div className="flex">
        <div className="py-1 mr-2">
          <Icon className="h-6 w-6" />
        </div>
        <div>{message}</div>
      </div>
    </div>
  );
}
