import { useEffect } from 'react';
import confetti from 'canvas-confetti';

interface CelebrationSimpleProps {
  onComplete?: () => void;
}

export function CelebrationSimple({ onComplete }: CelebrationSimpleProps = {}) {
  useEffect(() => {
    console.log("Simple celebration triggered");
    
    // Create and fire confetti
    const end = Date.now() + (5 * 1000);
    
    // Immediate burst
    const colors = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];
    
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 },
      colors: colors
    });
    
    // Set up animation loop
    const frame = () => {
      confetti({
        particleCount: 2,
        angle: 60,
        spread: 55,
        origin: { x: 0 },
        colors: colors
      });
      
      confetti({
        particleCount: 2,
        angle: 120,
        spread: 55,
        origin: { x: 1 },
        colors: colors
      });
      
      if (Date.now() < end) {
        requestAnimationFrame(frame);
      }
    };
    frame();
    
    // Show a congratulatory message
    const message = document.createElement('div');
    message.className = 'fixed inset-0 flex items-center justify-center z-50 pointer-events-none';
    message.innerHTML = `
      <div class="bg-gradient-to-r from-indigo-600 to-blue-500 text-white px-10 py-8 rounded-lg shadow-xl">
        <h2 class="text-4xl font-bold mb-3 text-center">Great Job! 🎉</h2>
        <p class="text-xl text-center">All contacts for this day have been contacted!</p>
      </div>
    `;
    document.body.appendChild(message);
    
    // Clean up
    setTimeout(() => {
      if (document.body.contains(message)) {
        document.body.removeChild(message);
      }
      // Call the onComplete callback if provided
      if (onComplete) {
        onComplete();
      }
    }, 5000);
  }, []);
  
  return null;
}