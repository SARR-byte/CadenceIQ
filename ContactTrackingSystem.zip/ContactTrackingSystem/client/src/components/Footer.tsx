import { useContactCounts } from "@/lib/hooks";
import { ContactStage } from "@shared/schema";

export function Footer() {
  const { data: counts = {} } = useContactCounts();
  
  const defaultCounts: Record<ContactStage, number> = {
    [ContactStage.FIRST_EMAIL]: 0,
    [ContactStage.SECOND_EMAIL]: 0,
    [ContactStage.PHONE_LINKEDIN]: 0,
    [ContactStage.BREAKUP_EMAIL]: 0,
  };
  
  const allCounts = { ...defaultCounts, ...counts as Record<ContactStage, number> };

  return (
    <div className="mt-4 flex justify-between items-center text-sm text-[hsl(var(--ms-gray-400))]">
      <div>© 2025 Cadence IQ</div>
      <div className="flex items-center">
        <div className="mr-6">
          First Email: <span className="font-semibold">{allCounts[ContactStage.FIRST_EMAIL]}</span> contacts
        </div>
        <div className="mr-6">
          Second Email: <span className="font-semibold">{allCounts[ContactStage.SECOND_EMAIL]}</span> contacts
        </div>
        <div className="mr-6">
          Phone/LinkedIn: <span className="font-semibold">{allCounts[ContactStage.PHONE_LINKEDIN]}</span> contacts
        </div>
        <div>
          Breakup Email: <span className="font-semibold">{allCounts[ContactStage.BREAKUP_EMAIL]}</span> contacts
        </div>
      </div>
    </div>
  );
}
