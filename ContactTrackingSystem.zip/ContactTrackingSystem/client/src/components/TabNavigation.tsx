import { useState, useEffect } from "react";
import { ContactDay, Contact } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";

interface TabNavigationProps {
  activeDay: ContactDay;
  onDayChange: (day: ContactDay) => void;
  completedDays?: ContactDay[];
}

export function TabNavigation({ activeDay, onDayChange, completedDays = [] }: TabNavigationProps) {
  const [dayCompletionStatus, setDayCompletionStatus] = useState<Record<ContactDay, boolean>>({
    [ContactDay.MONDAY]: false,
    [ContactDay.TUESDAY]: false,
    [ContactDay.WEDNESDAY]: false,
    [ContactDay.THURSDAY]: false,
    [ContactDay.FRIDAY]: false,
  });
  
  // Fetch contacts for each day to determine completion status
  const fetchDayStatus = async () => {
    const newStatus = { ...dayCompletionStatus };
    
    for (const day of Object.values(ContactDay)) {
      try {
        const response = await fetch(`/api/contacts/${day}`);
        const contacts = await response.json() as Contact[];
        
        // Day is complete if all contacts have been attempted
        const isComplete = contacts.length > 0 && contacts.every(contact => contact.contactAttempted);
        newStatus[day] = isComplete;
      } catch (error) {
        console.error(`Error checking completion status for ${day}:`, error);
      }
    }
    
    setDayCompletionStatus(newStatus);
  };
  
  // Check completion status when component mounts and when activeDay changes
  useEffect(() => {
    fetchDayStatus();
    
    // Set up a refresh interval to periodically check completion status
    const intervalId = setInterval(fetchDayStatus, 5000); // Check every 5 seconds
    
    return () => clearInterval(intervalId);
  }, [activeDay]);
  
  const tabs = [
    { id: ContactDay.MONDAY, label: "Monday" },
    { id: ContactDay.TUESDAY, label: "Tuesday" },
    { id: ContactDay.WEDNESDAY, label: "Wednesday" },
    { id: ContactDay.THURSDAY, label: "Thursday" },
    { id: ContactDay.FRIDAY, label: "Friday" },
  ];

  return (
    <div className="flex border-b border-[hsl(var(--ms-gray-300))] mb-1">
      {tabs.map((tab) => (
        <button
          key={tab.id}
          onClick={() => onDayChange(tab.id)}
          className={`px-4 py-2 mr-1 rounded-t-md flex items-center space-x-2 ${
            activeDay === tab.id ? "tab-active" : "tab-inactive"
          }`}
        >
          <span>{tab.label}</span>
          {dayCompletionStatus[tab.id] && (
            <span className="inline-flex items-center justify-center w-5 h-5 bg-green-600 text-white rounded-full">
              <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="20 6 9 17 4 12"></polyline>
              </svg>
            </span>
          )}
        </button>
      ))}
    </div>
  );
}
