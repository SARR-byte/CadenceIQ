import { Mail, Phone, Send } from "lucide-react";
import { ContactStage } from "@shared/schema";

interface EmptyStateProps {
  stage: ContactStage;
}

export function EmptyState({ stage }: EmptyStateProps) {
  let icon = <Mail className="h-16 w-16 mb-4 text-[hsl(var(--ms-gray-400))]" />;
  let title = "No contacts yet";
  let message = "Add contacts to start tracking your outreach";

  switch (stage) {
    case ContactStage.FIRST_EMAIL:
      icon = <Mail className="h-16 w-16 mb-4 text-[hsl(var(--ms-gray-400))]" />;
      title = "No contacts in First Email stage";
      message = "Add new contacts to begin your outreach process";
      break;
    case ContactStage.SECOND_EMAIL:
      icon = <Mail className="h-16 w-16 mb-4 text-[hsl(var(--ms-gray-400))]" />;
      title = "No contacts moved to Second Email yet";
      message = "Mark contacts as 'Attempted' in First Email to move them here";
      break;
    case ContactStage.PHONE_LINKEDIN:
      icon = <Phone className="h-16 w-16 mb-4 text-[hsl(var(--ms-gray-400))]" />;
      title = "No contacts moved to Phone/LinkedIn Outreach yet";
      message = "Mark contacts as 'Attempted' in Second Email to move them here";
      break;
    case ContactStage.BREAKUP_EMAIL:
      icon = <Send className="h-16 w-16 mb-4 text-[hsl(var(--ms-gray-400))]" />;
      title = "No contacts moved to Breakup Email yet";
      message = "Mark contacts as 'Attempted' in Phone/LinkedIn Outreach to move them here";
      break;
  }

  return (
    <div className="flex flex-col items-center justify-center py-16 text-[hsl(var(--ms-gray-400))]">
      {icon}
      <p className="text-lg">{title}</p>
      <p className="text-sm mt-2">{message}</p>
    </div>
  );
}
