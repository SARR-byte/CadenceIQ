import { useState, useEffect, useRef } from "react";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Contact, ContactStage } from "@shared/schema";
import { EmptyState } from "./EmptyState";
import { LightbulbIcon, EyeIcon, CalendarIcon } from "lucide-react";
import { format, addDays } from "date-fns";

interface ContactGridProps {
  contacts: Contact[];
  stage: ContactStage;
  isLoading: boolean;
  onValueChange: (id: number, field: string, value: string) => void;
  onAttemptedChange: (id: number, attempted: boolean) => void;
  onSelectionChange: (selectedIds: number[]) => void;
  onGenerateInsights?: (id: number) => void;
  isGeneratingInsights?: boolean;
  onViewNote?: (note: string) => void;
}

export function ContactGrid({
  contacts,
  stage,
  isLoading,
  onValueChange,
  onAttemptedChange,
  onSelectionChange,
  onGenerateInsights,
  isGeneratingInsights = false,
  onViewNote,
}: ContactGridProps) {
  const [selectedRows, setSelectedRows] = useState<Set<number>>(new Set());
  const [editingCell, setEditingCell] = useState<{
    id: number;
    field: string;
  } | null>(null);
  // Add refs for container and scroll position management
  const gridContainerRef = useRef<HTMLDivElement>(null);
  const scrollPositionRef = useRef<{x: number, y: number} | null>(null);
  
  // Handle selection of a single row
  const handleRowSelect = (id: number, checked: boolean) => {
    const newSelected = new Set(selectedRows);
    
    if (checked) {
      newSelected.add(id);
    } else {
      newSelected.delete(id);
    }
    
    setSelectedRows(newSelected);
    onSelectionChange(Array.from(newSelected));
  };

  // Handle select all checkbox
  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      const allIds = contacts.map(c => c.id);
      setSelectedRows(new Set(allIds));
      onSelectionChange(allIds);
    } else {
      setSelectedRows(new Set());
      onSelectionChange([]);
    }
  };

  // When cell is clicked, make it editable
  const handleCellClick = (id: number, field: string) => {
    // Store current scroll position to prevent position jumps
    const containerScrollTop = gridContainerRef.current?.scrollTop || 0;
    
    if (field === 'notes' && contacts.find(c => c.id === id)?.notes && onViewNote) {
      // If there are notes and we click outside the view button area, show modal
      onViewNote(contacts.find(c => c.id === id)!.notes!);
    } else {
      setEditingCell({ id, field });
      
      // Restore scroll position after React updates the DOM
      setTimeout(() => {
        if (gridContainerRef.current) {
          gridContainerRef.current.scrollTop = containerScrollTop;
        }
      }, 0);
    }
  };

  // Calculate tabIndex for each cell
  const getTabIndex = (contactId: number, field: string) => {
    // Define the field order for tab navigation
    const fieldOrder = [
      'entityName',
      'primaryContact',
      'emailAddress',
      'phoneNumber',
      'companyLinkedIn',
      'contactLinkedIn',
      'contactFacebook',
      'notes'
    ];
    
    // Find the contact index in the contacts array
    const contactIndex = contacts.findIndex(c => c.id === contactId);
    if (contactIndex === -1) return 0;
    
    // Find the field index in the fieldOrder array
    const fieldIndex = fieldOrder.indexOf(field);
    if (fieldIndex === -1) return 0;
    
    // Calculate a unique tabIndex based on row and column
    // Each row starts with index * 100, then add field index
    // This ensures tab order goes across each row before moving to the next row
    return (contactIndex * 100) + fieldIndex + 1; // +1 to avoid tabIndex=0 which is default tab order
  };

  // Handle tab key navigation
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>, contactId: number, field: string) => {
    if (e.key === 'Tab') {
      // Store current scroll position to prevent jumps
      const containerScrollTop = gridContainerRef.current?.scrollTop || 0;
      
      // Define the field order for tab navigation
      const fieldOrder = [
        'entityName',
        'primaryContact',
        'emailAddress',
        'phoneNumber',
        'companyLinkedIn',
        'contactLinkedIn',
        'contactFacebook',
        'notes'
      ];
      
      // Find the current field index in the field order
      const currentFieldIndex = fieldOrder.indexOf(field);
      
      // Save the current field value regardless of tab direction
      onValueChange(contactId, field, e.currentTarget.value);
      
      // If we're not at the last field and not holding shift, move to the next field
      if (!e.shiftKey && currentFieldIndex < fieldOrder.length - 1) {
        e.preventDefault(); // Prevent default tab behavior
        
        // Set focus to the next field in the same row
        const nextField = fieldOrder[currentFieldIndex + 1];
        setEditingCell({ id: contactId, field: nextField });
        
        // Restore scroll position after React updates the DOM
        setTimeout(() => {
          if (gridContainerRef.current) {
            gridContainerRef.current.scrollTop = containerScrollTop;
          }
        }, 0);
      } 
      // If we're not at the first field and holding shift, move to the previous field
      else if (e.shiftKey && currentFieldIndex > 0) {
        e.preventDefault(); // Prevent default tab behavior
        
        // Set focus to the previous field in the same row
        const prevField = fieldOrder[currentFieldIndex - 1];
        setEditingCell({ id: contactId, field: prevField });
        
        // Restore scroll position after React updates the DOM
        setTimeout(() => {
          if (gridContainerRef.current) {
            gridContainerRef.current.scrollTop = containerScrollTop;
          }
        }, 0);
      }
      // Otherwise, let the browser handle the tab (move to next row or UI element)
      else {
        setEditingCell(null);
      }
    } else if (e.key === 'Enter') {
      e.preventDefault();
      onValueChange(contactId, field, e.currentTarget.value);
      setEditingCell(null);
    }
  };

  // When editing is complete
  const handleBlur = (id: number, field: string, value: string) => {
    // Store current scroll position to prevent jumps
    const containerScrollTop = gridContainerRef.current?.scrollTop || 0;
    
    onValueChange(id, field, value);
    // Don't immediately clear editing cell on blur, to support tab navigation
    // The key handler will clear it when appropriate
    
    // Restore scroll position after value change processing
    setTimeout(() => {
      if (gridContainerRef.current) {
        gridContainerRef.current.scrollTop = containerScrollTop;
      }
    }, 0);
  };
  
  // Removed window blur event that was causing issues with tabbing out

  // Calculate next contact date based on stage
  const getNextContactDate = (contact: Contact) => {
    if (!contact.stageTransitionDate) return "Not scheduled";
    
    let daysToAdd: number;
    
    switch (contact.stage) {
      case ContactStage.SECOND_EMAIL:
        daysToAdd = 7;
        break;
      case ContactStage.PHONE_LINKEDIN:
        daysToAdd = 14;
        break;
      case ContactStage.BREAKUP_EMAIL:
        daysToAdd = 21;
        break;
      default:
        daysToAdd = 7;
    }
    
    const today = new Date();
    const nextDate = addDays(today, daysToAdd);
    return format(nextDate, "MMM d, yyyy");
  };

  // Show empty state if there are no contacts
  if (!isLoading && contacts.length === 0) {
    return <EmptyState stage={stage} />;
  }

  const allSelected = contacts.length > 0 && selectedRows.size === contacts.length;
  const someSelected = selectedRows.size > 0 && selectedRows.size < contacts.length;

  // Render the grid
  return (
    <div className="bg-white border border-[hsl(var(--ms-gray-300))] rounded overflow-hidden">
      <div className="overflow-x-auto w-full overflow-y-hidden">
        {/* Grid header row */}
        <div className="flex grid-header-cell border-b border-[hsl(var(--ms-gray-300))] bg-[hsl(var(--ms-gray-200))]">
          <div className="grid-cell grid-header-cell px-2 py-2 w-10 flex items-center justify-center">
            <Checkbox 
              checked={allSelected}
              className="h-4 w-4"
              data-indeterminate={someSelected ? "true" : "false"}
              onCheckedChange={handleSelectAll}
            />
          </div>
          <div className="grid-cell grid-header-cell col-entity px-2 py-2">Entity Name</div>
          <div className="grid-cell grid-header-cell col-contact px-2 py-2">Primary Contact</div>
          <div className="grid-cell grid-header-cell col-email px-2 py-2">Email Address</div>
          <div className="grid-cell grid-header-cell col-phone px-2 py-2">Phone Number</div>
          <div className="grid-cell grid-header-cell col-linkedin px-2 py-2">Company LinkedIn</div>
          <div className="grid-cell grid-header-cell col-contact-linkedin px-2 py-2">Contact LinkedIn</div>
          <div className="grid-cell grid-header-cell col-facebook px-2 py-2">Contact Facebook</div>
          <div className="grid-cell grid-header-cell col-notes px-2 py-2">Notes</div>
          <div className="grid-cell grid-header-cell col-insights px-2 py-2 relative">
            <div className="group flex items-center justify-center">
              <LightbulbIcon className="h-4 w-4 mr-1 text-yellow-400" />
              <span>Insights</span>
              <div className="insights-tooltip">
                Click the lightbulb to generate insights from LinkedIn and Facebook profiles
              </div>
            </div>
          </div>
          {stage !== ContactStage.FIRST_EMAIL && (
            <div className="grid-cell grid-header-cell col-next-date px-2 py-2">Next Contact Date</div>
          )}
          <div className="grid-cell grid-header-cell col-attempted px-2 py-2">Contact Attempted</div>
        </div>

        {/* Grid container with stable minimum height to prevent cells from jumping */}
        <div ref={gridContainerRef} className="contacts-grid-container min-h-[500px] max-h-[calc(100vh-300px)] overflow-y-auto">
          {contacts.map((contact) => (
            <div
              key={contact.id}
              className="flex hover:bg-[hsl(var(--ms-gray-100))]"
            >
              {/* Checkbox column */}
              <div className="grid-cell px-2 py-1 w-10 flex items-center justify-center">
                <Checkbox
                  checked={selectedRows.has(contact.id)}
                  className="h-4 w-4"
                  onCheckedChange={(checked) => 
                    handleRowSelect(contact.id, checked === true)
                  }
                />
              </div>
              
              {/* Entity Name Cell */}
              <div className="grid-cell col-entity px-2 py-1" onClick={() => handleCellClick(contact.id, 'entityName')}>
                {editingCell?.id === contact.id && editingCell?.field === 'entityName' ? (
                  <input
                    type="text"
                    className="w-full h-full outline-none border-2 border-[hsl(var(--chrome-dark))] bg-white p-1"
                    defaultValue={contact.entityName || ''}
                    onBlur={(e) => handleBlur(contact.id, 'entityName', e.target.value)}
                    onKeyDown={(e) => handleKeyDown(e, contact.id, 'entityName')}
                    tabIndex={getTabIndex(contact.id, 'entityName')}
                    autoFocus
                  />
                ) : (
                  <div className="cursor-pointer w-full h-full">
                    {contact.entityName}
                  </div>
                )}
              </div>
              
              {/* Primary Contact Cell */}
              <div className="grid-cell col-contact px-2 py-1" onClick={() => handleCellClick(contact.id, 'primaryContact')}>
                {editingCell?.id === contact.id && editingCell?.field === 'primaryContact' ? (
                  <input
                    type="text"
                    className="w-full h-full outline-none border-2 border-[hsl(var(--chrome-dark))] bg-white p-1"
                    defaultValue={contact.primaryContact || ''}
                    onBlur={(e) => handleBlur(contact.id, 'primaryContact', e.target.value)}
                    onKeyDown={(e) => handleKeyDown(e, contact.id, 'primaryContact')}
                    tabIndex={getTabIndex(contact.id, 'primaryContact')}
                    autoFocus
                  />
                ) : (
                  <div className="cursor-pointer w-full h-full">
                    {contact.primaryContact}
                  </div>
                )}
              </div>
              
              {/* Email Address Cell */}
              <div className="grid-cell col-email px-2 py-1" onClick={() => handleCellClick(contact.id, 'emailAddress')}>
                {editingCell?.id === contact.id && editingCell?.field === 'emailAddress' ? (
                  <input
                    type="text"
                    className="w-full h-full outline-none border-2 border-[hsl(var(--chrome-dark))] bg-white p-1"
                    defaultValue={contact.emailAddress || ''}
                    onBlur={(e) => handleBlur(contact.id, 'emailAddress', e.target.value)}
                    onKeyDown={(e) => handleKeyDown(e, contact.id, 'emailAddress')}
                    tabIndex={getTabIndex(contact.id, 'emailAddress')}
                    autoFocus
                  />
                ) : (
                  <div className="cursor-pointer w-full h-full">
                    {contact.emailAddress}
                  </div>
                )}
              </div>
              
              {/* Phone Number Cell */}
              <div className="grid-cell col-phone px-2 py-1" onClick={() => handleCellClick(contact.id, 'phoneNumber')}>
                {editingCell?.id === contact.id && editingCell?.field === 'phoneNumber' ? (
                  <input
                    type="text"
                    className="w-full h-full outline-none border-2 border-[hsl(var(--chrome-dark))] bg-white p-1"
                    defaultValue={contact.phoneNumber || ''}
                    onBlur={(e) => handleBlur(contact.id, 'phoneNumber', e.target.value)}
                    onKeyDown={(e) => handleKeyDown(e, contact.id, 'phoneNumber')}
                    tabIndex={getTabIndex(contact.id, 'phoneNumber')}
                    autoFocus
                  />
                ) : (
                  <div className="cursor-pointer w-full h-full">
                    {contact.phoneNumber}
                  </div>
                )}
              </div>
              
              {/* Company LinkedIn Cell */}
              <div className="grid-cell col-linkedin px-2 py-1" onClick={() => handleCellClick(contact.id, 'companyLinkedIn')}>
                {editingCell?.id === contact.id && editingCell?.field === 'companyLinkedIn' ? (
                  <input
                    type="text"
                    className="w-full h-full outline-none border-2 border-[hsl(var(--chrome-dark))] bg-white p-1"
                    defaultValue={contact.companyLinkedIn || ''}
                    onBlur={(e) => handleBlur(contact.id, 'companyLinkedIn', e.target.value)}
                    onKeyDown={(e) => handleKeyDown(e, contact.id, 'companyLinkedIn')}
                    tabIndex={getTabIndex(contact.id, 'companyLinkedIn')}
                    autoFocus
                  />
                ) : (
                  <div className="cursor-pointer w-full h-full">
                    {contact.companyLinkedIn}
                  </div>
                )}
              </div>
              
              {/* Contact LinkedIn Cell */}
              <div className="grid-cell col-contact-linkedin px-2 py-1" onClick={() => handleCellClick(contact.id, 'contactLinkedIn')}>
                {editingCell?.id === contact.id && editingCell?.field === 'contactLinkedIn' ? (
                  <input
                    type="text"
                    className="w-full h-full outline-none border-2 border-[hsl(var(--chrome-dark))] bg-white p-1"
                    defaultValue={contact.contactLinkedIn || ''}
                    onBlur={(e) => handleBlur(contact.id, 'contactLinkedIn', e.target.value)}
                    onKeyDown={(e) => handleKeyDown(e, contact.id, 'contactLinkedIn')}
                    tabIndex={getTabIndex(contact.id, 'contactLinkedIn')}
                    autoFocus
                  />
                ) : (
                  <div className="cursor-pointer w-full h-full">
                    {contact.contactLinkedIn}
                  </div>
                )}
              </div>
              
              {/* Contact Facebook Cell */}
              <div className="grid-cell col-facebook px-2 py-1" onClick={() => handleCellClick(contact.id, 'contactFacebook')}>
                {editingCell?.id === contact.id && editingCell?.field === 'contactFacebook' ? (
                  <input
                    type="text"
                    className="w-full h-full outline-none border-2 border-[hsl(var(--chrome-dark))] bg-white p-1"
                    defaultValue={contact.contactFacebook || ''}
                    onBlur={(e) => handleBlur(contact.id, 'contactFacebook', e.target.value)}
                    onKeyDown={(e) => handleKeyDown(e, contact.id, 'contactFacebook')}
                    tabIndex={getTabIndex(contact.id, 'contactFacebook')}
                    autoFocus
                  />
                ) : (
                  <div className="cursor-pointer w-full h-full">
                    {contact.contactFacebook}
                  </div>
                )}
              </div>
              
              {/* Notes Cell */}
              <div className="grid-cell col-notes px-2 py-1">
                {editingCell?.id === contact.id && editingCell?.field === 'notes' ? (
                  <input
                    type="text"
                    className="w-full h-full outline-none border-2 border-[hsl(var(--chrome-dark))] bg-white p-1"
                    defaultValue={contact.notes || ''}
                    onBlur={(e) => handleBlur(contact.id, 'notes', e.target.value)}
                    onKeyDown={(e) => handleKeyDown(e, contact.id, 'notes')}
                    tabIndex={getTabIndex(contact.id, 'notes')}
                    autoFocus
                  />
                ) : (
                  <div 
                    className="cursor-pointer w-full h-full" 
                    onClick={(e) => {
                      const target = e.target as Element;
                      if (contact.notes && target.closest && target.closest('.text-blue-500')) {
                        if (onViewNote) {
                          onViewNote(contact.notes);
                        }
                      } else {
                        handleCellClick(contact.id, 'notes');
                      }
                    }}
                  >
                    {contact.notes ? (
                      <>
                        {contact.notes}
                        <span className="text-blue-500 ml-1 inline-flex items-center text-xs">
                          <span className="ml-1 mr-1">View</span>
                          <EyeIcon className="h-3 w-3" />
                        </span>
                      </>
                    ) : null}
                  </div>
                )}
              </div>
              
              {/* Insights column with lightbulb button */}
              <div className="grid-cell col-insights px-2 py-1 flex justify-center items-center">
                {onGenerateInsights && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 w-8 p-0"
                    onClick={() => onGenerateInsights(contact.id)}
                    disabled={isGeneratingInsights}
                    title="Generate insights from social profile data"
                  >
                    <LightbulbIcon 
                      className={`h-5 w-5 ${isGeneratingInsights ? 'animate-pulse text-amber-500' : 'text-yellow-400'}`} 
                    />
                  </Button>
                )}
              </div>
              
              {/* Next contact date cell */}
              {stage !== ContactStage.FIRST_EMAIL && (
                <div className="grid-cell col-next-date px-2 py-1 flex items-center">
                  {contact.stageTransitionDate ? (
                    <div className="flex items-center text-blue-600">
                      <CalendarIcon className="h-4 w-4 mr-1" />
                      <span>{getNextContactDate(contact)}</span>
                    </div>
                  ) : (
                    <span className="text-gray-500">Not scheduled</span>
                  )}
                </div>
              )}
              
              {/* Contact Attempted toggle */}
              <div className="grid-cell col-attempted px-2 py-1 flex justify-center items-center">
                <Switch
                  checked={contact.contactAttempted}
                  onCheckedChange={(checked) => onAttemptedChange(contact.id, checked)}
                  className={`${
                    contact.contactAttempted 
                      ? 'bg-[hsl(var(--ms-success))]' 
                      : 'bg-[hsl(var(--ms-gray-200))]'
                  } relative inline-flex h-6 w-11 items-center rounded-full`}
                />
              </div>
            </div>
          ))}
          
          {/* Loading skeleton rows */}
          {isLoading && 
            Array.from({ length: 5 }).map((_, i) => (
              <div key={`skeleton-${i}`} className="flex animate-pulse">
                <div className="grid-cell px-2 py-1 w-10 flex items-center justify-center">
                  <div className="h-4 w-4 bg-gray-200 rounded" />
                </div>
                <div className="grid-cell col-entity px-2 py-1">
                  <div className="h-4 bg-gray-200 rounded w-3/4" />
                </div>
                <div className="grid-cell col-contact px-2 py-1">
                  <div className="h-4 bg-gray-200 rounded w-2/3" />
                </div>
                <div className="grid-cell col-email px-2 py-1">
                  <div className="h-4 bg-gray-200 rounded w-4/5" />
                </div>
                <div className="grid-cell col-phone px-2 py-1">
                  <div className="h-4 bg-gray-200 rounded w-1/2" />
                </div>
                <div className="grid-cell col-linkedin px-2 py-1">
                  <div className="h-4 bg-gray-200 rounded w-3/4" />
                </div>
                <div className="grid-cell col-contact-linkedin px-2 py-1">
                  <div className="h-4 bg-gray-200 rounded w-3/4" />
                </div>
                <div className="grid-cell col-facebook px-2 py-1">
                  <div className="h-4 bg-gray-200 rounded w-3/4" />
                </div>
                <div className="grid-cell col-notes px-2 py-1">
                  <div className="h-4 bg-gray-200 rounded w-2/3" />
                </div>
                <div className="grid-cell col-insights px-2 py-1 flex justify-center items-center">
                  <div className="h-5 w-5 bg-gray-200 rounded-full" />
                </div>
                {stage !== ContactStage.FIRST_EMAIL && (
                  <div className="grid-cell col-next-date px-2 py-1">
                    <div className="h-4 bg-gray-200 rounded w-2/3" />
                  </div>
                )}
                <div className="grid-cell col-attempted px-2 py-1 flex justify-center items-center">
                  <div className="h-4 w-8 bg-gray-200 rounded-full" />
                </div>
              </div>
            ))
          }
        </div>
      </div>
    </div>
  );
}