import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PlusIcon, TrashIcon, UploadIcon } from "lucide-react";
import { CsvUploadModal } from "./CsvUploadModal";
import { useQueryClient } from "@tanstack/react-query";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface ToolbarProps {
  rowCount: number;
  selectedRows: number[];
  onAddRow: (showNotification?: boolean) => boolean | void;
  onAddMultipleRows?: (count: number) => void;
  onDeleteSelected: () => void;
  onSearch: (query: string) => void;
}

export function Toolbar({
  rowCount,
  selectedRows,
  onAddRow,
  onAddMultipleRows,
  onDeleteSelected,
  onSearch,
}: ToolbarProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [isCsvModalOpen, setIsCsvModalOpen] = useState(false);
  const queryClient = useQueryClient();

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const query = e.target.value;
    setSearchQuery(query);
    onSearch(query);
  };
  
  const handleCsvUploadSuccess = () => {
    // First invalidate all contact-related queries to ensure fresh data is fetched
    queryClient.invalidateQueries({ queryKey: ['/api/contacts'] });
    
    // Also explicitly invalidate the contact counts
    queryClient.invalidateQueries({ queryKey: ['/api/contacts/counts'] });
    
    // Invalidate specific day queries (all days)
    const days = ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY'];
    days.forEach(day => {
      queryClient.invalidateQueries({ queryKey: [`/api/contacts/${day}`] });
    });
    
    // Also trigger a search refresh
    onSearch(searchQuery);
    
    // Complete page reload after a short delay to ensure all data is refreshed
    setTimeout(() => {
      window.location.reload();
    }, 800);
  };

  return (
    <div className="flex justify-between items-center mb-4 p-2 bg-white border border-[hsl(var(--ms-gray-300))] rounded">
      <div className="flex items-center">
        <div className="flex mr-4">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="default" 
                  size="sm" 
                  className="bg-[#333333] hover:bg-[#222222] text-white rounded-r-none"
                  onClick={() => onAddRow(true)}
                >
                  <PlusIcon className="h-4 w-4 mr-1" />
                  Add Row
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Add a new empty contact row to the current day</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          
          <div className="relative">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="default" 
                    size="sm" 
                    className="bg-[#333333] hover:bg-[#222222] text-white rounded-l-none border-l-2 border-[#222222] px-2"
                    onClick={() => {
                      const count = prompt("How many rows would you like to add?", "1");
                      if (count) {
                        const numCount = parseInt(count);
                        if (!isNaN(numCount) && numCount > 0) {
                          if (onAddMultipleRows) {
                            onAddMultipleRows(numCount);
                          } else {
                            // Fallback if onAddMultipleRows is not provided
                            for (let i = 0; i < numCount; i++) {
                              onAddRow(false);
                            }
                          }
                        }
                      }
                    }}
                  >
                    <span className="text-xs font-bold">+</span>
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Add multiple contact rows at once</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </div>
        <Button
          variant="secondary"
          size="sm"
          className="mr-4"
          disabled={selectedRows.length === 0}
          onClick={onDeleteSelected}
        >
          <TrashIcon className="h-4 w-4 mr-1" />
          Delete Selected
        </Button>
        <Button
          variant="default"
          size="sm"
          className="mr-4 bg-[#333333] hover:bg-[#222222] text-white"
          onClick={() => setIsCsvModalOpen(true)}
        >
          <UploadIcon className="h-4 w-4 mr-1" />
          Import CSV
        </Button>
      </div>
      <div className="flex items-center">
        <div className="text-sm text-[hsl(var(--ms-gray-400))] mr-4">
          {rowCount} rows
        </div>
        <Input
          type="text"
          placeholder="Search..."
          className="px-3 py-1 border border-[hsl(var(--ms-gray-300))] rounded text-sm"
          value={searchQuery}
          onChange={handleSearchChange}
        />
      </div>
      
      {/* CSV Upload Modal */}
      <CsvUploadModal 
        isOpen={isCsvModalOpen}
        onClose={() => setIsCsvModalOpen(false)}
        onSuccess={handleCsvUploadSuccess}
      />
    </div>
  );
}
