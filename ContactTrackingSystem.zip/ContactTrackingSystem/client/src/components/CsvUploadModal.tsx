import { useState } from "react";
import { ContactDay } from "@shared/schema";
import { X, Upload, FileUp, Copy, Check } from "lucide-react";
import { Button } from "./ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Label } from "./ui/label";
import { Input } from "./ui/input";
import { Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface CsvUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export function CsvUploadModal({ isOpen, onClose, onSuccess }: CsvUploadModalProps) {
  const [selectedDay, setSelectedDay] = useState<ContactDay | "">("");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  const { toast } = useToast();

  const handleDayChange = (value: string) => {
    setSelectedDay(value as ContactDay);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setSelectedFile(e.target.files[0]);
    }
  };
  
  // Format with exact field names to match the database schema
  const sampleCsvContent = `Entity Name,Primary Contact,Email Address,Phone Number,Company LinkedIn Profile,Primary Contact LinkedIn Profile,Primary Contact Facebook Profile,Notes
ABC Industries,Jane Williams,jane.williams@example.com,555-123-4567,linkedin.com/company/abc,linkedin.com/in/jane-w,,Follow up needed
XYZ Corp,John Smith,john.smith@example.com,555-987-6543,linkedin.com/company/xyz,linkedin.com/in/john-s,facebook.com/john.s,Met at conference`;

  const handleCopyTemplate = async () => {
    try {
      await navigator.clipboard.writeText(sampleCsvContent);
      setIsCopied(true);
      toast({
        title: "Copied to clipboard",
        description: "CSV template copied to clipboard successfully",
        variant: "default",
      });
      
      // Reset the copied status after 2 seconds
      setTimeout(() => {
        setIsCopied(false);
      }, 2000);
    } catch (err) {
      console.error("Failed to copy template:", err);
      toast({
        title: "Copy failed",
        description: "Could not copy template to clipboard",
        variant: "destructive",
      });
    }
  };

  const handleUpload = async () => {
    if (!selectedFile || !selectedDay) {
      toast({
        title: "Missing information",
        description: "Please select both a day and a CSV file to upload.",
        variant: "destructive",
      });
      return;
    }

    setIsUploading(true);

    try {
      // Create FormData for file upload
      const formData = new FormData();
      formData.append("file", selectedFile);
      formData.append("day", selectedDay);

      // Use the API request function to upload file
      const response = await fetch("/api/contacts/upload-csv", {
        method: "POST",
        body: formData,
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.message || "Failed to upload CSV file");
      }

      // Show success message with more details
      toast({
        title: "CSV Upload Successful",
        description: `Imported ${result.imported} contacts out of ${result.total} records. The page will refresh momentarily to show your new contacts.`,
        variant: "default",
      });

      // Reset form
      setSelectedFile(null);
      setSelectedDay("");
      
      // Close modal first for better UX
      onClose();
      
      // Then trigger the refresh data callback
      onSuccess();
    } catch (err: unknown) {
      const error = err as Error;
      console.error("Error uploading CSV:", error);
      toast({
        title: "Upload Failed",
        description: error.message || "Failed to upload CSV file. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl">Upload CSV Contacts</DialogTitle>
          <DialogDescription>
            Use this to import contacts from a CSV file. Each row will create a new contact for the selected day.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-6 py-4">
          <div className="grid gap-2">
            <Label htmlFor="day">Select Day</Label>
            <Select value={selectedDay} onValueChange={handleDayChange}>
              <SelectTrigger id="day">
                <SelectValue placeholder="Select a day" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={ContactDay.MONDAY}>Monday</SelectItem>
                <SelectItem value={ContactDay.TUESDAY}>Tuesday</SelectItem>
                <SelectItem value={ContactDay.WEDNESDAY}>Wednesday</SelectItem>
                <SelectItem value={ContactDay.THURSDAY}>Thursday</SelectItem>
                <SelectItem value={ContactDay.FRIDAY}>Friday</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid gap-2">
            <Label htmlFor="csv-file">CSV File</Label>
            <div className="flex items-center gap-2">
              <Input
                id="csv-file"
                type="file"
                accept=".csv"
                onChange={handleFileChange}
                className="flex-1"
              />
              {selectedFile && (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setSelectedFile(null)}
                >
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>
          </div>

          <div className="border rounded-md p-4 bg-muted/50">
            <h3 className="text-sm font-medium mb-2">CSV Format Guidelines</h3>
            <p className="text-sm text-muted-foreground mb-2">
              Your CSV should have the following columns in exact order (column headers must match precisely):
            </p>
            <ul className="text-xs text-muted-foreground list-disc pl-5 space-y-1 mb-3">
              <li>Entity Name</li>
              <li>Primary Contact</li>
              <li>Email Address</li>
              <li>Phone Number</li>
              <li>Company LinkedIn Profile</li>
              <li>Primary Contact LinkedIn Profile</li>
              <li>Primary Contact Facebook Profile</li>
              <li>Notes</li>
            </ul>
            <div className="mt-2 flex justify-center">
              <Button 
                size="sm"
                variant="outline"
                className="gap-2"
                onClick={handleCopyTemplate}
              >
                {isCopied ? (
                  <>
                    <Check className="h-4 w-4 text-green-600" />
                    Copied to clipboard!
                  </>
                ) : (
                  <>
                    <Copy className="h-4 w-4" />
                    Copy CSV template
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-3">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button
            onClick={handleUpload}
            disabled={isUploading || !selectedFile || !selectedDay}
            className="gap-1"
          >
            {isUploading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Uploading...
              </>
            ) : (
              <>
                <FileUp className="h-4 w-4" />
                Upload CSV
              </>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}