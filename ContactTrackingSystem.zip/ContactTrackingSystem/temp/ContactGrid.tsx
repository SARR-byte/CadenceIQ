import { useState, useEffect, useRef } from "react";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Contact, ContactStage } from "@shared/schema";
import { EmptyState } from "./EmptyState";
import { LightbulbIcon, EyeIcon, CalendarIcon } from "lucide-react";
import { format, addDays } from "date-fns";

interface ContactGridProps {
  contacts: Contact[];
  stage: ContactStage;
  isLoading: boolean;
  onValueChange: (id: number, field: string, value: string) => void;
  onAttemptedChange: (id: number, attempted: boolean) => void;
  onSelectionChange: (selectedIds: number[]) => void;
  onGenerateInsights?: (id: number) => void;
  isGeneratingInsights?: boolean;
  onViewNote?: (note: string) => void;
}

export function ContactGrid({
  contacts,
  stage,
  isLoading,
  onValueChange,
  onAttemptedChange,
  onSelectionChange,
  onGenerateInsights,
  isGeneratingInsights = false,
  onViewNote,
}: ContactGridProps) {
  const [selectedRows, setSelectedRows] = useState<Set<number>>(new Set());
  const [editingCell, setEditingCell] = useState<{
    id: number;
    field: string;
  } | null>(null);
  
  // Reference to the currently edited cell
  const editableCellRef = useRef<HTMLInputElement>(null);

  // Handle selection of a single row
  const handleRowSelect = (id: number, checked: boolean) => {
    const newSelected = new Set(selectedRows);
    
    if (checked) {
      newSelected.add(id);
    } else {
      newSelected.delete(id);
    }
    
    setSelectedRows(newSelected);
    onSelectionChange(Array.from(newSelected));
  };

  // Handle select all checkbox
  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      const allIds = contacts.map(c => c.id);
      setSelectedRows(new Set(allIds));
      onSelectionChange(allIds);
    } else {
      setSelectedRows(new Set());
      onSelectionChange([]);
    }
  };

  // Handle cell editing
  const handleCellClick = (id: number, field: string) => {
    if (field === 'notes') {
      // Show notes in modal if it has content, otherwise edit
      const contact = contacts.find(c => c.id === id);
      if (contact?.notes && onViewNote) {
        // Use the onViewNote prop to show notes in a modal
        onViewNote(contact.notes);
      } else {
        setEditingCell({ id, field });
      }
    } else if (field !== 'contactAttempted') {
      setEditingCell({ id, field });
    }
  };

  // Define the column order for tab navigation
  const columnOrder = [
    'entityName',
    'primaryContact',
    'emailAddress',
    'phoneNumber',
    'companyLinkedIn',
    'contactLinkedIn',
    'contactFacebook',
    'notes'
  ];

  // Handle cell key press with improved tab navigation
  const handleCellKeyDown = (e: React.KeyboardEvent<HTMLInputElement>, id: number, field: string) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      setEditingCell(null);
    } else if (e.key === 'Tab') {
      e.preventDefault(); // Prevent default tab behavior

      // Find the current field index in the column order
      const currentIndex = columnOrder.indexOf(field);
      
      // If at the end of columns or not found, do nothing (let browser handle tab)
      if (currentIndex === -1 || currentIndex === columnOrder.length - 1) {
        setEditingCell(null);
        return;
      }
      
      // Get the next field in the column order
      const nextField = columnOrder[currentIndex + 1];
      
      // Set focus to the next field in the same row
      setEditingCell({ id, field: nextField });
    }
  };

  // Focus the cell when it becomes editable
  useEffect(() => {
    if (editingCell && editableCellRef.current) {
      editableCellRef.current.focus();
    }
  }, [editingCell]);
  
  // Calculate next contact date based on stage
  const getNextContactDate = (contact: Contact) => {
    if (!contact.stageTransitionDate) return "Not scheduled";
    
    let daysToAdd: number;
    
    switch (contact.stage) {
      case ContactStage.SECOND_EMAIL:
        daysToAdd = 7;
        break;
      case ContactStage.PHONE_LINKEDIN:
        daysToAdd = 14;
        break;
      case ContactStage.BREAKUP_EMAIL:
        daysToAdd = 21;
        break;
      default:
        daysToAdd = 7;
    }
    
    const today = new Date();
    const nextDate = addDays(today, daysToAdd);
    return format(nextDate, "MMM d, yyyy");
  };

  // Show empty state if there are no contacts
  if (!isLoading && contacts.length === 0) {
    return <EmptyState stage={stage} />;
  }

  const allSelected = contacts.length > 0 && selectedRows.size === contacts.length;
  const someSelected = selectedRows.size > 0 && selectedRows.size < contacts.length;

  // Render the grid
  return (
    <div className="bg-white border border-[hsl(var(--ms-gray-300))] rounded overflow-hidden">
      <div className="overflow-x-auto w-full">
        {/* Grid header row */}
        <div className="flex grid-header-cell border-b border-[hsl(var(--ms-gray-300))] bg-[hsl(var(--ms-gray-200))]">
          <div className="grid-cell grid-header-cell px-2 py-2 w-10 flex items-center justify-center">
            <Checkbox 
              checked={allSelected}
              className="h-4 w-4"
              data-indeterminate={someSelected ? "true" : "false"}
              onCheckedChange={handleSelectAll}
            />
          </div>
          <div className="grid-cell grid-header-cell col-entity px-2 py-2">Entity Name</div>
          <div className="grid-cell grid-header-cell col-contact px-2 py-2">Primary Contact</div>
          <div className="grid-cell grid-header-cell col-email px-2 py-2">Email Address</div>
          <div className="grid-cell grid-header-cell col-phone px-2 py-2">Phone Number</div>
          <div className="grid-cell grid-header-cell col-linkedin px-2 py-2">Company LinkedIn</div>
          <div className="grid-cell grid-header-cell col-contact-linkedin px-2 py-2">Contact LinkedIn</div>
          <div className="grid-cell grid-header-cell col-facebook px-2 py-2">Contact Facebook</div>
          <div className="grid-cell grid-header-cell col-notes px-2 py-2">Notes</div>
          <div className="grid-cell grid-header-cell col-insights px-2 py-2 relative">
            <div className="group flex items-center justify-center">
              <LightbulbIcon className="h-4 w-4 mr-1 text-yellow-400" />
              <span>Insights</span>
              <div className="insights-tooltip">
                Click the lightbulb to generate insights from LinkedIn and Facebook profiles
              </div>
            </div>
          </div>
          {stage !== ContactStage.FIRST_EMAIL && (
            <div className="grid-cell grid-header-cell col-next-date px-2 py-2">Next Contact Date</div>
          )}
          <div className="grid-cell grid-header-cell col-attempted px-2 py-2">Contact Attempted</div>
        </div>

        {/* Grid container with overflow */}
        <div className="contacts-grid-container max-h-[calc(100vh-220px)] overflow-y-auto">
          {contacts.map((contact) => (
            <div
              key={contact.id}
              className="flex hover:bg-[hsl(var(--ms-gray-100))]"
            >
              <div className="grid-cell px-2 py-1 w-10 flex items-center justify-center">
                <Checkbox
                  checked={selectedRows.has(contact.id)}
                  className="h-4 w-4"
                  onCheckedChange={(checked) => 
                    handleRowSelect(contact.id, checked === true)
                  }
                />
              </div>
              
              {/* Entity Name Cell */}
              <div className="grid-cell col-entity px-2 py-1">
                {editingCell?.id === contact.id && editingCell?.field === 'entityName' ? (
                  <input
                    type="text"
                    className="w-full h-full outline-none border-2 border-[hsl(var(--chrome-dark))] bg-white"
                    defaultValue={contact.entityName || ''}
                    ref={editableCellRef}
                    onBlur={(e) => onValueChange(contact.id, 'entityName', e.target.value)}
                    onKeyDown={(e) => handleCellKeyDown(e, contact.id, 'entityName')}
                    autoFocus
                  />
                ) : (
                  <div 
                    className="cursor-pointer w-full h-full" 
                    onClick={() => handleCellClick(contact.id, 'entityName')}
                  >
                    {contact.entityName}
                  </div>
                )}
              </div>
              
              {/* Primary Contact Cell */}
              <div className="grid-cell col-contact px-2 py-1">
                {editingCell?.id === contact.id && editingCell?.field === 'primaryContact' ? (
                  <input
                    type="text"
                    className="w-full h-full outline-none border-2 border-[hsl(var(--chrome-dark))] bg-white"
                    defaultValue={contact.primaryContact || ''}
                    onBlur={(e) => onValueChange(contact.id, 'primaryContact', e.target.value)}
                    onKeyDown={(e) => handleCellKeyDown(e, contact.id, 'primaryContact')}
                    autoFocus
                  />
                ) : (
                  <div 
                    className="cursor-pointer w-full h-full" 
                    onClick={() => handleCellClick(contact.id, 'primaryContact')}
                  >
                    {contact.primaryContact}
                  </div>
                )}
              </div>
              
              {/* Email Address Cell */}
              <div className="grid-cell col-email px-2 py-1">
                {editingCell?.id === contact.id && editingCell?.field === 'emailAddress' ? (
                  <input
                    type="text"
                    className="w-full h-full outline-none border-2 border-[hsl(var(--chrome-dark))] bg-white"
                    defaultValue={contact.emailAddress || ''}
                    onBlur={(e) => onValueChange(contact.id, 'emailAddress', e.target.value)}
                    onKeyDown={(e) => handleCellKeyDown(e, contact.id, 'emailAddress')}
                    autoFocus
                  />
                ) : (
                  <div 
                    className="cursor-pointer w-full h-full" 
                    onClick={() => handleCellClick(contact.id, 'emailAddress')}
                  >
                    {contact.emailAddress}
                  </div>
                )}
              </div>
              
              {/* Phone Number Cell */}
              <div className="grid-cell col-phone px-2 py-1">
                {editingCell?.id === contact.id && editingCell?.field === 'phoneNumber' ? (
                  <input
                    type="text"
                    className="w-full h-full outline-none border-2 border-[hsl(var(--chrome-dark))] bg-white"
                    defaultValue={contact.phoneNumber || ''}
                    onBlur={(e) => onValueChange(contact.id, 'phoneNumber', e.target.value)}
                    onKeyDown={(e) => handleCellKeyDown(e, contact.id, 'phoneNumber')}
                    autoFocus
                  />
                ) : (
                  <div 
                    className="cursor-pointer w-full h-full" 
                    onClick={() => handleCellClick(contact.id, 'phoneNumber')}
                  >
                    {contact.phoneNumber}
                  </div>
                )}
              </div>
              
              {/* Company LinkedIn Cell */}
              <div className="grid-cell col-linkedin px-2 py-1">
                {editingCell?.id === contact.id && editingCell?.field === 'companyLinkedIn' ? (
                  <input
                    type="text"
                    className="w-full h-full outline-none border-2 border-[hsl(var(--chrome-dark))] bg-white"
                    defaultValue={contact.companyLinkedIn || ''}
                    onBlur={(e) => onValueChange(contact.id, 'companyLinkedIn', e.target.value)}
                    onKeyDown={(e) => handleCellKeyDown(e, contact.id, 'companyLinkedIn')}
                    autoFocus
                  />
                ) : (
                  <div 
                    className="cursor-pointer w-full h-full" 
                    onClick={() => handleCellClick(contact.id, 'companyLinkedIn')}
                  >
                    {contact.companyLinkedIn}
                  </div>
                )}
              </div>
              
              {/* Contact LinkedIn Cell */}
              <div className="grid-cell col-contact-linkedin px-2 py-1">
                {editingCell?.id === contact.id && editingCell?.field === 'contactLinkedIn' ? (
                  <input
                    type="text"
                    className="w-full h-full outline-none border-2 border-[hsl(var(--chrome-dark))] bg-white"
                    defaultValue={contact.contactLinkedIn || ''}
                    onBlur={(e) => onValueChange(contact.id, 'contactLinkedIn', e.target.value)}
                    onKeyDown={(e) => handleCellKeyDown(e, contact.id, 'contactLinkedIn')}
                    autoFocus
                  />
                ) : (
                  <div 
                    className="cursor-pointer w-full h-full" 
                    onClick={() => handleCellClick(contact.id, 'contactLinkedIn')}
                  >
                    {contact.contactLinkedIn}
                  </div>
                )}
              </div>
              
              {/* Contact Facebook Cell */}
              <div className="grid-cell col-facebook px-2 py-1">
                {editingCell?.id === contact.id && editingCell?.field === 'contactFacebook' ? (
                  <input
                    type="text"
                    className="w-full h-full outline-none border-2 border-[hsl(var(--chrome-dark))] bg-white"
                    defaultValue={contact.contactFacebook || ''}
                    onBlur={(e) => onValueChange(contact.id, 'contactFacebook', e.target.value)}
                    onKeyDown={(e) => handleCellKeyDown(e, contact.id, 'contactFacebook')}
                    autoFocus
                  />
                ) : (
                  <div 
                    className="cursor-pointer w-full h-full" 
                    onClick={() => handleCellClick(contact.id, 'contactFacebook')}
                  >
                    {contact.contactFacebook}
                  </div>
                )}
              </div>
              
              {/* Notes Cell */}
              <div className="grid-cell col-notes px-2 py-1">
                {editingCell?.id === contact.id && editingCell?.field === 'notes' ? (
                  <input
                    type="text"
                    className="w-full h-full outline-none border-2 border-[hsl(var(--chrome-dark))] bg-white"
                    defaultValue={contact.notes || ''}
                    onBlur={(e) => onValueChange(contact.id, 'notes', e.target.value)}
                    onKeyDown={(e) => handleCellKeyDown(e, contact.id, 'notes')}
                    autoFocus
                  />
                ) : (
                  <div 
                    className="cursor-pointer w-full h-full" 
                    onClick={(e) => {
                      const target = e.target as Element;
                      if (contact.notes && target.closest && target.closest('.text-blue-500')) {
                        if (onViewNote) {
                          onViewNote(contact.notes);
                        }
                      } else {
                        handleCellClick(contact.id, 'notes');
                      }
                    }}
                  >
                    {contact.notes ? (
                      <>
                        {contact.notes}
                        <span className="text-blue-500 ml-1 inline-flex items-center text-xs">
                          <span className="ml-1 mr-1">View</span>
                          <EyeIcon className="h-3 w-3" />
                        </span>
                      </>
                    ) : null}
                  </div>
                )}
              </div>
              
              {/* Insights column with lightbulb button */}
              <div className="grid-cell col-insights px-2 py-1 flex justify-center items-center">
                {onGenerateInsights && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 w-8 p-0"
                    onClick={() => onGenerateInsights(contact.id)}
                    disabled={isGeneratingInsights}
                    title="Generate insights from social profile data"
                  >
                    <LightbulbIcon 
                      className={`h-5 w-5 ${isGeneratingInsights ? 'animate-pulse text-amber-500' : 'text-yellow-400'}`} 
                    />
                  </Button>
                )}
              </div>
              
              {/* Next contact date cell */}
              {stage !== ContactStage.FIRST_EMAIL && (
                <div className="grid-cell col-next-date px-2 py-1 flex items-center">
                  {contact.stageTransitionDate ? (
                    <div className="flex items-center text-blue-600">
                      <CalendarIcon className="h-4 w-4 mr-1" />
                      <span>{getNextContactDate(contact)}</span>
                    </div>
                  ) : (
                    <span className="text-gray-500">Not scheduled</span>
                  )}
                </div>
              )}
              
              {/* Contact Attempted toggle */}
              <div className="grid-cell col-attempted px-2 py-1 flex justify-center items-center">
                <Switch
                  checked={contact.contactAttempted}
                  onCheckedChange={(checked) => onAttemptedChange(contact.id, checked)}
                  className={`${
                    contact.contactAttempted 
                      ? 'bg-[hsl(var(--ms-success))]' 
                      : 'bg-[hsl(var(--ms-gray-200))]'
                  } relative inline-flex h-6 w-11 items-center rounded-full`}
                />
              </div>
            </div>
          ))}
          
          {/* Loading skeleton rows */}
          {isLoading && 
            Array.from({ length: 5 }).map((_, i) => (
              <div key={`skeleton-${i}`} className="flex animate-pulse">
                <div className="grid-cell px-2 py-1 w-10 flex items-center justify-center">
                  <div className="h-4 w-4 bg-gray-200 rounded" />
                </div>
                <div className="grid-cell col-entity px-2 py-1">
                  <div className="h-4 bg-gray-200 rounded w-3/4" />
                </div>
                <div className="grid-cell col-contact px-2 py-1">
                  <div className="h-4 bg-gray-200 rounded w-2/3" />
                </div>
                <div className="grid-cell col-email px-2 py-1">
                  <div className="h-4 bg-gray-200 rounded w-4/5" />
                </div>
                <div className="grid-cell col-phone px-2 py-1">
                  <div className="h-4 bg-gray-200 rounded w-1/2" />
                </div>
                <div className="grid-cell col-linkedin px-2 py-1">
                  <div className="h-4 bg-gray-200 rounded w-3/4" />
                </div>
                <div className="grid-cell col-contact-linkedin px-2 py-1">
                  <div className="h-4 bg-gray-200 rounded w-3/4" />
                </div>
                <div className="grid-cell col-facebook px-2 py-1">
                  <div className="h-4 bg-gray-200 rounded w-3/4" />
                </div>
                <div className="grid-cell col-notes px-2 py-1">
                  <div className="h-4 bg-gray-200 rounded w-2/3" />
                </div>
                <div className="grid-cell col-insights px-2 py-1 flex justify-center items-center">
                  <div className="h-5 w-5 bg-gray-200 rounded-full" />
                </div>
                {stage !== ContactStage.FIRST_EMAIL && (
                  <div className="grid-cell col-next-date px-2 py-1">
                    <div className="h-4 bg-gray-200 rounded w-2/3" />
                  </div>
                )}
                <div className="grid-cell col-attempted px-2 py-1 flex justify-center items-center">
                  <div className="h-4 w-8 bg-gray-200 rounded-full" />
                </div>
              </div>
            ))
          }
        </div>
      </div>
    </div>
  );
}